Documents in this directory describe deprecated Proximity features and
functionality.