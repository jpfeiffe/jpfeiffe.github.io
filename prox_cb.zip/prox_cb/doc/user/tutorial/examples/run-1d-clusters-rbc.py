# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Import the necessary class definitions.
from kdl.prox.old.script import EstItemModelAttr
from kdl.prox.old.model.classifiers import RBC

# Make sample "0" the training set and sample "1" the test set.
trainContainer = prox.getContainer("1d-clusters/samples/0")
testContainer = prox.getContainer("1d-clusters/samples/1")

# ---------------------------------
# Define what we want to predict.

# The subgraph object whose label we want to predict
coreItemName = 'core_page'

# The name of the attribute we want to predict
attrToPredict = 'isStudent'

# The attribute we want to predict.
# Format: item name, 
#         attribute name,
#         0/1=core item is link/object,
#         0/1=attribute is not continuous/continuous

classLabel = EstItemModelAttr(coreItemName, attrToPredict, 1, 0)

# The set of features we'll use in learning the model.
# Features are attributes of the core item, links connecting to the
# core item, or objects linked to the core item (in general, this can
# be multiple "hops" away; for this model, we're only interested in
# attributes within one hop of the core item)
# Format: item name,
#         attribute name, 
#         0/1=item is link/object,
#         0/1=attribute is not continuous/continuous

inputItemAttrs = [ \
   EstItemModelAttr('core_page', 'url_server_info', 1, 0), \
   EstItemModelAttr('core_page', 'url_hierarchy1b', 1, 0), \
   EstItemModelAttr('linked_from_page', 'url_server_info', 1, 0), \
   EstItemModelAttr('linked_from_page', 'url_hierarchy1b', 1, 0), \
   EstItemModelAttr('linked_from_page', 'page_num_outlinks', 1, 0), \
   EstItemModelAttr('linked_from_page', 'page_num_inlinks', 1, 0), \
   EstItemModelAttr('linked_to_page', 'url_server_info', 1, 0), \
   EstItemModelAttr('linked_to_page', 'url_hierarchy1b', 1, 0), \
   EstItemModelAttr('linked_to_page', 'page_num_outlinks', 1, 0), \
   EstItemModelAttr('linked_to_page', 'page_num_inlinks', 1, 0), \
   EstItemModelAttr('linked_to', 'link_tag', 0, 0), \
   EstItemModelAttr('linked_from', 'link_tag', 0, 0)]

# ---------------------------------
# Begin modeling portion of script

print "Beginning modeling section"

# Instantiate the model.
print "Instantiating model..."
modelName = "ProxWebKB_RBC"
#rbc = prox.instantiateRBC(modelName)
rbc = RBC(modelName)

# Induce (train) the model.
print "Inducing model..."
rbc.induceModel(trainContainer, classLabel, inputItemAttrs)

# Output XML.
xmlFileName = modelName + '.xml'
rbc.saveAsXML(xmlFileName)
print "RBC written to ", xmlFileName

# Apply the model to the test set.
print "Applying model..."
rbc.applyModel(testContainer)

# Delete the rbc_isStudent_prediction attribute if it already exists
rbcAttrName = "rbc_isStudent_prediction"
currentAttrs = prox.objectAttrs
if currentAttrs.isAttributeDefined(rbcAttrName):
      currentAttrs.deleteAttribute(rbcAttrName)

# Write out the predictions
print "Writing predictions..."
rbc.writePredictions(rbcAttrName)

# A value of 1 for the isStudent attribute means page is a student page.
posLabel = 1

# Evaluate the model.
print "Computing accuracy (ACC)..."
acc = rbc.accuracy()
print "Computing area under ROC curve (AUC)..."
auc = rbc.areaUnderROC(str(posLabel))
print "Computing conditional likelihood (CLL)..."
cll = rbc.conditionalLikelihood()

# Print summary of all results.
print "RBC results: "
print "  ACC: ", str(acc)
print "  AUC: ", str(auc)
print "  CLL: ", str(cll)

