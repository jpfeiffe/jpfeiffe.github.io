# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Get the two sample set containers.
firstSample = prox.getContainer("1d-clusters/samples/0")
secondSample = prox.getContainer("1d-clusters/samples/1")

# Get the OIDs of the subgraphs in each of the sample sets.
firstSampleSubgraphOIDs = firstSample.getSubgraphOIDs()
secondSampleSubgraphOIDs = secondSample.getSubgraphOIDs()

# Report on the number of subgraphs in each sample set.
firstNumSubgraphs = len(firstSampleSubgraphOIDs)
secondNumSubgraphs = len(secondSampleSubgraphOIDs)

print "Number of subgraphs in the sample containers"
print "  Sample 0 contains", firstNumSubgraphs, " subgraphs"
print "  Sample 1 contains", secondNumSubgraphs, " subgraphs"

# Examine the objects and links in one of the subgraphs.
# Get the OID of the first subgraph in the first sample set.
testID = firstSampleSubgraphOIDs[0]

# Get the subgraph that has that OID.
testSubgraph = firstSample.getSubgraph(testID)

# Get the objects and links in this subgraph.
testObjs = testSubgraph.getObjects()
testLinks = testSubgraph.getLinks()

# Find out how many objects and links there are in this subgraph.
numObjs = testObjs.size()
numLinks = testLinks.size()

# Report the number of and OIDs for the objects and links in this subgraph.
print "Subgraph ", testID, " statistics:"
print "   Number of objects: ", numObjs
print "      Object OIDs:",
for obj in testObjs:
    print " ", obj.getOid(),
print " "
print "   Number of links: ", numLinks
print "      Link OIDs:",
for link in testLinks:
    print " ", link.getOid(),
print " "

# Get the attribute values for each object in this subgraph.
# We omit the page_words_top100 attributes for output brevity.
# The values in an AttributeValue object are an array of strings.

objAttrs = prox.objectAttrs
for obj in testObjs:
    oid = obj.getOid()
    print "Attributes for object", oid
    attrValues = objAttrs.getAttrValsForOID(oid)
    attrValList = attrValues.getAttrValues()
    for attr in attrValList:
        name = attr.getName()
        if name != 'page_words_top100':
           valArray = attr.getValues()
           val = valArray[0]
           print "  ", name, " = ", val

# Get the attribute values for each link in this subgraph.

linkAttrs = prox.linkAttrs
for link in testLinks:
    oid = link.getOid()
    print "Attributes for link", oid
    attrValues = linkAttrs.getAttrValsForOID(oid)
    attrValList = attrValues.getAttrValues()
    for attr in attrValList:
        name = attr.getName()
        valArray = attr.getValues()
        val = valArray[0]
        print "  ", name, " = ", val


