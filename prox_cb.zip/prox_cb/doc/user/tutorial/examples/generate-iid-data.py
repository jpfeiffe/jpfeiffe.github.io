# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Generate synthetic i.i.d. data.

# I.i.d. data generation creates a set of 1d-star subgraphs each having a
# core object (S) and linked (peripheral) objects (T).  We give each
# instance in S a single, discrete attribute that's used as a class
# label.  We also add a number of discrete attributes to the objects
# in S and T.

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# WARNING: erases the database; run on a new or test database!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

from kdl.prox.old.datagen import DataGenerator
from kdl.prox.util.stat import NormalDistribution
from kdl.prox.old.model.classifiers import RPT

# Define a helper function that reads RPT files
def loadClassifier(modelFile):
    rpt = RPT("datagen RPT")
    rpt.readFromXML(modelFile)
    return rpt

# Data generation requires an empty database. Check to see if the
# database already contains data so we can warn users accordingly.

# Returns true if the top-level tables are defined and empty
isEmpty = DB.isProxTablesEmpty()

# If database is NOT empty, ask user whether to overwrite the
# existing data.

genData = 1
if (not isEmpty):
   prompt = "Database is not empty. Overwrite existing data?"
   genData = prox.getYesNoFromUser(prompt)

# Do nothing if the database is not empty and the user says "No"

if (not genData):
   print 'No data generated.'

# Continue if database is empty or if user says to overwrite
# existing data

else:
   print 'Clearing database'
   DB.clearDB()
   print 'Initializing database'
   DB.initEmptyDB()

   # Create a DataGenerator instance.
   # Provide name of a new container that will hold the generated data
   dataGenerator = DataGenerator("datagen-out")

   # ------------------------------------------------------------
   # Generate the graph structure
   # ------------------------------------------------------------

   # Specify a probability distribution over degree distributions for
   # the S objects.

   # We create graphs that contain two different degree distributions
   # for the S objects.  One half of the S objects have normally
   # distributed degrees with a mean of 2 and standard deviation
   # approaching zero. The second half have normally distributed
   # degrees with a mean of 5 and standard deviation of 1.

   degreeDistribs = [[0.5, NormalDistribution(2.0, 0.0000001)],
                     [0.5, NormalDistribution(5.0, 1.0)]]

   # Generate the i.i.d. graph structure.  The generated data will
   # include four S objects.

   print 'creating graph structure'
   dataGenerator.generateIIDStructure(4, degreeDistribs)

   # ------------------------------------------------------------
   # Generate attribute values
   # ------------------------------------------------------------

   # Specify the prior probability distributions of the class labels
   # and attribute values.

   # Each inner array is of the form [Dn, Pn] where Dn specifies a
   # degree for S and Pn specifies the probability that S objects with
   # Dn-1 < degree <= D will be labeled as a positive example.
   # In this example, S objects with degree of 1 have a probability of
   # 0.05 of being labeled as a positive example, those with
   # degree of 2 have a probability of 0.15 of being labeled as a
   # positive example, those with degree 3 through 5 have a
   # probability of 0.75 of being labeled as a positive instance, and
   # any S objects with degree greater than 5 up to the maximum have a
   # probability of 0.15 of being labeled as a positive instance.

   sClassPrior = [[[1], [0.05, 0.000001]], [[2], [0.15, 0.00001]], [[5], [0.75, 0.00001]],
                  [[DataGenerator.DEGREE_RANGE_MAX], [0.15, 0.000001]]]

   # Specify the prior probability distributions of the attribute
   # values for both S and T objects.  Each attribute must have its
   # own prior probability distribution. The probabilities for each
   # attribute must total 1.0.

   # S objects have a single attribute that can take one of three
   # discrete values (red, blue, or green)

   sAttrPriors = [[["red", 0.2], ["blue", 0.2], ["green", 0.6]]]

   # T objects have a single attribute that can be either 0 or 1.

   tAttrPriors = [[[1, 0.5], [0, 0.5]]]

   # Data generation uses RPTs to specify how other data in the graph
   # (e.g., the attribute values for neighboring objects) conditions
   # the prior probabilities for the class labels and attribute values.

   # Do not condition the class labels for this example.

   sClassCPD = None

   # Specify an array of RPTs (one per attribute) to condition the
   # attribute values for S and T objects.

   sAttrCPDs = [loadClassifier("s-attr-rpt.xml")]
   tAttrCPDs = [loadClassifier("t-attr-rpt.xml")]

   # We include a tolerance test to see if the sClassCPD RPT has
   # modified the distribution of class labels to be "far" from that
   # specified by the prior probability distribution. A tolerance of
   # 0.2 means that for each degree range specified in sClassPrior,
   # the final distribution of class labels must fall within +/- 0.2
   # of the prior probability for that degree range.  (Because we do
   # not provide an sClassCPD in this example, our final class
   # label distribution will not change from that specified by
   # sClassPrior.

   tolerance = 0.5

   # Specify the number of Gibbs sampling iterations to use in
   # conditioning the data

   iters = 3

   # Specify the name of the container that will hold the generated data

   containerName = "generated-iid-data"

   # The call to generateIIDAttributes returns true if method was able
   # to generate values which met the tolerance criterion

   print 'generating i.i.d. attributes()'
   isGenerateSuccessful = dataGenerator.generateIIDAttributes(sClassPrior,
        sAttrPriors, tAttrPriors, sClassCPD, sAttrCPDs, tAttrCPDs,
        tolerance, iters, containerName)
   print 'generation status (1 = successful): ', isGenerateSuccessful

