# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Generate synthetic lattice data.

# Lattice data generation cretaes a connected graph with a regular
# lattice structure. All objects are the same type, S.
# We give each instance in S a single, discrete attribute that's used
# as a class label plus additional discrete attributes to be used
# during classification.

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# WARNING: erases the database; run on a new or test database!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

from kdl.prox.old.datagen import DataGenerator
from kdl.prox.old.datagen import NormalDistribution
from kdl.prox.old.model.classifiers import RPT

# Define a helper function that reads RPT files
def loadClassifier(modelFile):
    rpt = RPT("datagen RPT")
    rpt.readFromXML(modelFile)
    return rpt

# Data generation requires an empty database. Check to see if the
# database already contains data so we can warn users accordingly.

# Returns true is the top-level tables are defined and empty
isEmpty = DB.isProxTablesEmpty()

# If database is not empty, ask user whether to overwrite the
# existing data.

genData = 1
if (not isEmpty):
   prompt = "Database is not empty. Overwrite existing data?"
   genData = prox.getYesNoFromUser(prompt)

# Do nothing if the database is not empty and the user says "No"

if (not genData):
   print 'No data generated.'

# Continue if database is empty or if user says to overwrite
# existing data

else:
   print 'Clearing database'
   DB.clearDB()
   print 'Initializing database'
   DB.initEmptyDB()

   # Create a DataGenerator instance.
   # Provide name of a new container that will hold the generated data
   dataGenerator = prox.instantiateDataGenerator("datagen-out")

   # ------------------------------------------------------------
   # Generate the graph structure
   # ------------------------------------------------------------

   # Generate the lattice graph structure.  The generated data will
   # create four by four a square lattice.

   print 'creating lattice structure'
   dataGenerator.generateLatticeStructure(4)

   # ------------------------------------------------------------
   # Generate attribute values
   # ------------------------------------------------------------

   # Specify the prior probability distribution of positive
   # examples. In this example, 75 percent of the objects will be
   # positive instances.

   sClassPrior = 0.75

   # Specify the prior probability distributions of the attribute
   # values. Each attribute must have its own prior probability
   # distribution. The probabilities for each attribute must total 1.0.

   # All objects have two attributes. The first can take one of three
   # discrete values (red, blue, or green). The second can take
   # be either 1 or 0.  (All attribute values are strings.)

   sAttrPriors = [[["red", 0.2], ["blue", 0.2], ["green", 0.6]],
                   [[1, 0.5], [0, 0.5]]]

   # Data generation uses RPTs to specify how other data in the graph
   # (e.g., the attribute values for neighboring objects) conditions
   # the prior probabilities for the class labels and attribute values.

   # Specify an RPT to condition the class labels.

   sClassCPD = loadClassifier("s-class-rpt.xml")

   # Specify an array of RPTs (one per attribute) to condition the
   # attribute values.  In this example, we do not condition the
   # attribute values.

   sAttrCPDs = [None, None]

   # We include a tolerance test to see if the sClassCPD RPT has
   # modified the distribution of class labels to be "far" from that
   # specified by the prior probability. A tolerance of 0.2 means that
   # the final distribution of class labels must fall within +/- 0.2
   # of the prior probability.

   tolerance = 0.5

   # Specify the number of Gibbs sampling iterations to use in
   # conditioning the data

   iters = 3

  # The call to generateLatticeAttributes returns true if method was able
  # to generate values which met the tolerance criterion

   print 'generating lattice attributes'
   isGenerateSuccessful = dataGenerator.generateLatticeAttributes(sClassPrior,
        sAttrPriors, sClassCPD, sAttrCPDs, tolerance, iters)
   print 'generation status (1 = successful): ', isGenerateSuccessful

