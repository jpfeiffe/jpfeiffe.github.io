# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Import the necessary class definitions.
from kdl.prox.script import EstItemModelAttr
from kdl.prox.old.model.features import FeatureManager

# Enable the reference vector feature
FeatureManager.enableFeature("kdl.prox.old.model.features.ReferenceVectorFeature")

# Make sample "0" the training set and sample "1" the test set.
trainContainer = prox.getContainer("1d-clusters/samples/0")
testContainer = prox.getContainer("1d-clusters/samples/1")

# ---------------------------------
# Define what we want to predict.

# The subgraph object whose label we want to predict
coreItemName = 'core_page'

# The name of the attribute we want to predict
attrToPredict = 'pagetype'

# The attribute we want to predict
# Format: item name, attribute name, 1=core item is object,
#         0=attribute is not continuous
classLabel = EstItemModelAttr(coreItemName, attrToPredict, 1, 0)

# The set of attributes we'll use in learning the model.
# We can use any of the attributes found in the input subgraghs
# including attribute on the core item, links connecting to the
# core item, or objects linked to the core item (in general, this can
# be multiple "hops" away. The specific instantiation of the RPT model
# in this example does not use link attributes and only considers
# attributes within one hop of the core item)
# Format: item name, attribute name, 1=core item is object,
#         0=attribute is not continuous

# To keep execution time down, this script uses a limited set of
# attributes for the model.

# Limited attribute set:
inputItemAttrs = [ \
   EstItemModelAttr('core_page', 'url_server_info', 1, 0), \
   EstItemModelAttr('core_page', 'url_hierarchy1b', 1, 0), \
   EstItemModelAttr('linked_from_page', 'page_num_outlinks', 1, 0), \
   EstItemModelAttr('linked_from_page', 'page_words_top100', 1, 0), \
   EstItemModelAttr('linked_to_page', 'page_num_inlinks', 1, 0)]

# ---------------------------------
# Begin modeling portion of script

print "Beginning modeling section"

# Instantiate the model.
print "Instantiating model..."
modelName = 'ProxWebKB_RefVector_RPT'

# To keep execution time down, this script instantiates the model
# using a method that turns off statistical correction techniques that
# improve the accuracy of the model at the expense of additional
# execution time. You can use a simpler instatiation method that uses
# default values for most of these parameters if you prefer, e.g.,
#rpt = prox.instantiateRPT(modelName)

# Parameters for the more fully specified method:
#   modelName - the name of the model
#   pVal - used to stop tree growth
#   max Depth - maximum tree depth
#   numThresh - number of threshold to consider in generating features
#   useAcCorrection - whether to use autocorrelation correction
#   useDdCorrection - whether to use degree disparity correction
rpt = prox.instantiateRPT(modelName, 0.05, 4, 4, 0, 0)

# Induce (train) the tree.
print "Inducing model..."
rpt.induceModel(trainContainer, classLabel, inputItemAttrs)

# Output XML.
xmlFileName = modelName + '.xml'
rpt.saveAsXML(xmlFileName)
print "RPT written to ", xmlFileName

# Apply the model to the test set.
print "Applying model..."
rpt.applyModel(testContainer)

# Delete the rpt_refvector_prediction attribute if it already exists
rptAttrName = "rpt_refvector_prediction"
currentAttrs = prox.objectAttrs
if currentAttrs.isAttributeDefined(rptAttrName):
      currentAttrs.deleteAttribute(rptAttrName)

# Write out the predictions
print "Writing predictions..."
rpt.writePredictions(rptAttrName)

# A value of 'Student' for the 'pagetype' attribute means page is a
# student page.
posLabel = 'Student'

# Evaluate the model.
print "Computing accuracy (ACC)..."
acc = rpt.accuracy()
print "Computing area under ROC curve (AUC)..."
auc = rpt.areaUnderROC(str(posLabel))
print "Computing conditional likelihood (CLL)..."
cll = rpt.conditionalLikelihood()

# Print summary of all results.
print "RPT results: "
print "  ACC: ", str(acc)
print "  AUC: ", str(auc)
print "  CLL: ", str(cll)


