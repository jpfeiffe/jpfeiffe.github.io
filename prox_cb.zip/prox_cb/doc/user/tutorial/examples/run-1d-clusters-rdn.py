# Part of the open-source Proximity system (see LICENSE for copyright
# and license information).

# Import the necessary class definitions.
from kdl.prox.script import EstItemModelAttr

# Disable the reference vector feature (in case this is run after
# enabling the feature in the run-refvector-rpt.py script).

from kdl.prox.old.model.features import FeatureManager
FeatureManager.disableFeature("kdl.prox.old.model.features.ReferenceVectorFeature")

# Sample "0" was the training set and sample "1" is the test set.
trainContainer = prox.getContainer("1d-clusters/samples/0")
testContainer = prox.getContainer("1d-clusters/samples/1")

# -------------------------
# Create component RPT
# -------------------------

# Define what we want to predict.

# The subgraph object whose label we want to predict
coreItemName = 'core_page'

# The name of the attribute we want to predict
attrToPredict = 'pagetype'

# The attribute we want to predict
# Format: item name, attribute name, 1=core item is object,
#         0=attribute is not continuous
classLabel = EstItemModelAttr(coreItemName, attrToPredict, 1, 0)

# The set of attributes we'll use in learning the model.
# Format: item name, attribute name, 1=core item is object,
#         0=attribute is not continuous

inputItemAttrs = [ \
   EstItemModelAttr('core_page', 'url_server_info', 1, 0), \
   EstItemModelAttr('core_page', 'url_hierarchy1b', 1, 0), \
   EstItemModelAttr('linked_from_page', 'page_num_outlinks', 1, 0), \
   EstItemModelAttr('linked_from_page', 'pagetype', 1, 0), \
   EstItemModelAttr('linked_to_page', 'pagetype', 1, 0), \
   EstItemModelAttr('linked_to_page', 'page_num_inlinks', 1, 0)]

# Begin modeling portion of script

# Instantiate the model.
print "Instantiating RPT..."
modelName = 'ProxWebKB_RPTforRDN'

# Parameters for instantiation:
#   modelName - the name of the model
#   pVal - used to stop tree growth
#   max Depth - maximum tree depth
#   numThresh - number of threshold to consider in generating features
#   useAcCorrection - whether to use autocorrelation correction
#   useDdCorrection - whether to use degree disparity correction

rpt = prox.instantiateRPT(modelName, 0.05, 4, 4, 0, 0)

# Induce (train) the tree.
print "Inducing model..."
rpt.induceModel(trainContainer, classLabel, inputItemAttrs)

# Output XML.
xmlFileName = modelName + '.xml'
rpt.saveAsXML(xmlFileName)
print "RPT written to ", xmlFileName

# -------------------------
# Instantiate the RDN
# -------------------------

print "Instantiating RDN..."
rdnName = 'PageType_RDN'

# Set the number of Gibbs sampling iterations.
# This script stops after 200 iterations to limit execution time for this
# tutorial example.  In practice, many more iterations are needed.
numIterations = 200

# Set the "burn-in" period for Gibbs sampling.
burnIn = 100

# Set the "gap" in previous Gibbs iterations to consider when doing
# new iterations
skipNum = 2

# Instantiate the RDN
rdn = prox.instantiateRDN(rdnName, numIterations, burnIn, skipNum)

# The component RPT has already been trained so there is no separate
# training step for the RDN.

# -------------------------
# Apply the RDN
# -------------------------

print "Applying RDN..."
rdn.applyModel({rpt: testContainer})

# Write out the predictions.  Applying the RDN employs Gibbs sampling to
# jointly estimate the marginal probabilities for each of its
# component models (the single RPT in this case). The RDN then sets the
# predictions in each component model.  Note that we write out the
# predictions from this component RPT rather than the RDN.

# Delete the rdn_pagetype_prediction attribute if it already exists
rdnAttrName = "rdn_pagetype_prediction"
currentAttrs = prox.objectAttrs
if currentAttrs.isAttributeDefined(rdnAttrName):
      currentAttrs.deleteAttribute(rdnAttrName)

# Write out the predictions
print "Writing predictions..."
rpt.writePredictions(rdnAttrName)

# -------------------------
# Evaluate the RDN
# -------------------------

# A value of 'Student' for the 'pagetype' attribute means page is a
# student page.
posLabel = 'Student'

print "Computing accuracy..."
acc = rdn.accuracy(rpt)
print "Computing area under ROC curve..."
auc = rdn.areaUnderROC(rpt,str(posLabel))

# Print summary of evaluation results.
print "RDN results: "
print "  Accuracy:             ", str(acc)
print "  Area under ROC curve: ", str(auc)

