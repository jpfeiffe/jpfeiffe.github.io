Directory for cookbook support (example) files.
