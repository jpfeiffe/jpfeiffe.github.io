# $Id: objdict-ex.py 3658 2007-10-15 16:29:11Z schapira $

from kdl.prox.impascii import ObjDict

prox.log.info("-> " + "'" + prox.scriptFile + "' running on database '" + \
	prox.dbName + "'. prox: '" + prox.toString())

isFirstRun = 0

if isFirstRun:
    prox.initDB();

OBJ_ATTR_STR_TYPE_NAME = "OBJ_ATTR_STR_TYPE_NAME"
objectAttrs = prox.proxDB.getObjectAttrs()
if isFirstRun:
    objectAttrs.defineAttribute(OBJ_ATTR_STR_TYPE_NAME, "str")

objDict = ObjDict(prox.proxDB, OBJ_ATTR_STR_TYPE_NAME)
if isFirstRun:
    objDict.putIDForName("a", 0)
    objDict.putIDForName("b", 1)
    objDict.putIDForName("c", 1)
    objDict.putIDForName("d", 2)
    objDict.putIDForName("d", 3)

badIDs = objDict.getIDsForName("bad-name")
aIDs = objDict.getIDsForName("a")
bIDs = objDict.getIDsForName("b")
cIDs = objDict.getIDsForName("c")
dIDs = objDict.getIDsForName("d")

print badIDs
print aIDs
print bIDs
print cIDs
print dIDs

prox.log.info('-> exiting script')
