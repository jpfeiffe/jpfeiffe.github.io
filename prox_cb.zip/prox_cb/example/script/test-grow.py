# $Id: test-grow.py 197 2003-07-03 15:22:14Z cornell $

proxDB = prox.getProxDB()

# create containers: root -> A -> B
root = proxDB.getRootContainer()
if (root.hasChild("A")):
     root.deleteChild("A")
contA = root.createChild("A", 1)
contB = contA.createChild("B",1)

# create a subgraph in B to hold the network
subgraph_id = contB.createSubgraph()
sg = contB.getSubgraph(subgraph_id)

# insert a random object (id:21280) into the subgraph and then grow the subgraph
# with objects and links in the neighborhood
sg.insertObject(21280, "center")
for count in range(2):
    print "growing: ", count
    sg.growNeighborhood()
