# $Id: nst-example.py 3658 2007-10-15 16:29:11Z schapira $

import sys
from java.lang import Exception
from kdl.prox.dbmgr import DataTypeEnum
from kdl.prox.dbmgr import NST
from kdl.prox.util import MonetUtil


# define helper functions

def printNST(nst):
    print nst, ": ", nst.getNSTColumns()
    resultSet = nst.selectRows()
    while (resultSet.next()):
        print "  ", resultSet.getColumnList()
    print


def printRawNST(rawNSTName):
    try:
        nstName = MonetUtil.undelimitValue(rawNSTName, DataTypeEnum.BAT);
        printNST(NST(proxDBMgr.getConnection(), nstName))
    except Exception:
        print "error for rawNSTName: ", rawNSTName, sys.exc_info()      # sys.exc_info()[0]


# get and print db, mgr

proxDB = prox.proxDB
proxDBMgr = proxDB.getProxDBMgr()

print proxDB, proxDBMgr


# print top and misc NSTs

topNSTs = [proxDBMgr.getContainerNST(), proxDBMgr.getContainerAttrNST(),
    proxDBMgr.getLinkNST(), proxDBMgr.getLinkAttrNST(),
    proxDBMgr.getObjectNST(), proxDBMgr.getObjectAttrNST()]
rawNSTNames = ["<>bad", "<tmp_xx>", "<tmp_97>"]     # only last ok

for nst in topNSTs:
    printNST(nst)

for rawNSTName in rawNSTNames:
    printRawNST(rawNSTName)
