# $Id: schema-example.py 371 2003-09-04 14:00:08Z cornell $
#
# This file is a sample script that creates the famous test database
# we used when developing the Proximity Monet schema.
#
# Warning: Erases the database!
#

import sys


# print start info
prox.log.info("-> " + "'" + prox.scriptFile + "' running on database '" + \
	prox.dbName + "'. prox: '" + prox.toString())


# erase database (asking first), and create objects and links, saving them in
# a temp container

proxDB = prox.getProxDB()
proxDBMgr = proxDB.getProxDBMgr()
if (input('erase ' + proxDB.toString() + '? ')) != 1:
    sys.exit()
prox.log.info('-> erasing database')
proxDBMgr.clear();
proxDBMgr.initEmptyDB();


prox.log.info('-> creating objects and links')
container = proxDB.createNewTempContainer(1)    # todo why can't I use 'True' here?
subgraphOID = container.createSubgraph()
subgraph = container.getSubgraph(subgraphOID)

for objectOID in range(1, 6):   # [1, 2, 3, 4, 5]
    proxDB.insertObject(objectOID)
    subgraph.insertObject(objectOID, "obj: %s" % objectOID)

linkIDs = {1: [1, 2], 2: [1, 4], 3: [1, 5], 4: [4, 5]}
for linkOID in linkIDs.keys():      # NB: keys() not needed in later Python versions
    o1OID = linkIDs[linkOID][0]
    o2OID = linkIDs[linkOID][1]
    proxDB.insertLink(linkOID, o1OID, o2OID)
    subgraph.insertLink(linkOID, "link: %s -> %s, %s" % (linkOID, o1OID, o2OID))


# define item attributes
objAttrs = proxDB.getObjectAttrs()
objAttrs.defineAttribute("obj-type", "str")
objAttrs.defineAttribute("gross-per-yr", "yr:int, gross:int")

linkAttrs = proxDB.getLinkAttrs()
linkAttrs.defineAttribute("link-type", "str")


# add item attributes
attrDataNST = objAttrs.getAttrDataNST("obj-type")
attrDataNST.insertRow(["1", "mov"])
attrDataNST.insertRow(["2", "act"])
attrDataNST.insertRow(["3", "mov"])
attrDataNST.insertRow(["4", "dir"])
attrDataNST.insertRow(["5", "dir"])

attrDataNST = objAttrs.getAttrDataNST("gross-per-yr")
attrDataNST.insertRow(["1", "80", "10"])
attrDataNST.insertRow(["1", "90", "5"])
attrDataNST.insertRow(["3", "91", "20"])
attrDataNST.insertRow(["3", "92", "15"])
attrDataNST.insertRow(["3", "93", "25"])

attrDataNST = linkAttrs.getAttrDataNST("link-type")
attrDataNST.insertRow(["1", "actor-of"])
attrDataNST.insertRow(["2", "actor-of"])
attrDataNST.insertRow(["3", "actor-of"])
attrDataNST.insertRow(["4", "married-to"])


# create the container hierarchy from our example notes:
# + root
#   + 1
#     + 3  (subgraphs: a, b, c - shared)
#     + 4
#   + 2    (subgraphs: a', b' - unshared)
#     + 5
#   + 6    (subgraphs: ~10,000 - shared)

prox.log.info('-> creating containers')
root = proxDB.getRootContainer()
dontCareShare = 1
c1 = root.createChild("1", dontCareShare)
c2 = root.createChild("2", 0)               # unshared
c6 = root.createChild("6", 1)               # shared
c3 = c1.createChild("3", 1)                 # shared
c4 = c1.createChild("4", dontCareShare)
c5 = c2.createChild("5", dontCareShare)


# add subgraphs to 2 and 3
prox.log.info('-> creating small subgraphs')
c2sap = c2.getSubgraph(c2.createSubgraph()) # a'
c2sbp = c2.getSubgraph(c2.createSubgraph()) # b'

c3sa = c3.getSubgraph(c3.createSubgraph())   # a
c3sb = c3.getSubgraph(c3.createSubgraph())   # b
c3sc = c3.getSubgraph(c3.createSubgraph())   # c


# define container attributes
# todo fix xx

# add container attributes
# todo fix xx


# define subgraph attributes
# todo fix xx

# add subgraph attributes
# todo fix xx


# add items to subgraphs to 2 and 3

prox.log.info('-> adding subgraph items')

# c2sap: objs : 1, 2, 3   (no names in c2)
# c2sap: links: none
c2sap.insertObject(1, None)
c2sap.insertObject(2, None)
c2sap.insertObject(3, None)

# c2sbp: objs : 4, 5
# c2sbp: links: 4
c2sbp.insertObject(4, None)
c2sbp.insertObject(5, None)
c2sbp.insertLink(4, None)

# c3sa: objs : 1:m, 2:a
# c3sa: links: 1:a-of
c3sa.insertObject(1, 'm')
c3sa.insertObject(2, 'a')
c3sa.insertLink(1, 'a-of')

# c3sb: objs : 3:m
# c3sb: links: none
c3sb.insertObject(3, 'm')

# c3sc: objs : 1:m, 4:a, 5:a
# c3sc: links: 2:a-of, 3:a-of
c3sc.insertObject(1, 'm')
c3sc.insertObject(4, 'a')
c3sc.insertObject(5, 'a')
c3sc.insertLink(2, 'a-of')
c3sc.insertLink(3, 'a-of')


# add many subgraphs to 6

prox.log.info('-> creating large subgraphs')
for i in range(10000):
    if ((i % 100) == 0):
        print i
    c6.createSubgraph()


# print container hierarchy

prox.log.info('-> containers:')
def printContainer(container, level):
    name = container.getName()
    printIndent(level)
    print name
    for childName in container.getChildrenNames():
        child = container.getChild(childName)
        printContainer(child, level + 1)

def printIndent(level):
    print "  " * level,

printContainer(root, 0)


# done
prox.log.info('-> exiting script')
