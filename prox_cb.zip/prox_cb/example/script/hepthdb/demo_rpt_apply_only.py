from kdl.prox.dbmgr import DataTypeEnum
from kdl.prox.script import EstItemModelAttr
from kdl.prox.gui2 import RocCurveJApplet
from kdl.prox.db import Attributes

proxdb = prox.getProxDB()
rootContainer = proxdb.getRootContainer()

# model settings
maxDepth = 6
rptPval = 0.05
thresholds = 2
modelName = 'm'
classLabelName = 'is_pub_phys_b'

# need to modify this and put rpt.dtd in same directory
xmlFileName = '/tmp/rpt_' + modelName + '_1996.xml'

# the output predicted attribute
predictionsAttrName = classLabelName + ':rpt_prediction'

# container
testColName = '1997-paper-citations-3d-phys-b-d'
testContainer = rootContainer.getChild(testColName)

# cleanup temporary attributes
testContainer.getSubgraphAttrs().deleteAttributesWithPrefix("rpt")
testContainer.getSubgraphAttrs().deleteAttributesWithPrefix("model")
objAttrs = prox.getProxDB().getObjectAttrs()
objAttrs.deleteAttributesWithPrefix("rpt")
if objAttrs.isAttributeDefined(predictionsAttrName):
    objAttrs.deleteAttributesWithPrefix(predictionsAttrName)

# --------------------------------

prox.log.info("***Begin RPT section of python script***")

# instantiate the model
rpt = prox.instantiateRPT(modelName, rptPval, maxDepth, thresholds)

# read in from XML
prox.log.info("***Reading in rpt from " + xmlFileName)
rpt.readFromXML(xmlFileName)

# apply the model to the test set
prox.log.info("***Applying model on " + testColName)
rpt.applyModel(testContainer)

# calculate accuracy
acc = rpt.accuracy()
prox.log.info("***Accuracy = " + str(acc))

# write out predictions
prox.log.info("***Writing out predictions to " + predictionsAttrName)
rpt.writePredictions(predictionsAttrName)

# plot ROC curve
prox.log.info("***Plotting ROC curve")
points = rpt.genRocPoints("1")
RocCurveJApplet.showCurveWindow(points)

