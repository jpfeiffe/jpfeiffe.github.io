from kdl.prox.gui2 import RocCurveJApplet
from java.lang import Double

def split(line):
	first = second = ''
	i = 0
	for char in line:
		if char == ' ':
			first = line[0:i]
			second = line[i+1:]
		else:
			i += 1
	return (first, second)

fileName = "/Users/mhay/prox-work/proximity3/example/script/hepthdb/roc_points.out"
handle = open(fileName, 'r')

list = []
for line in handle.readlines():
	line = line[:-1]
	(x, y) = split(line)
	first = Double(x)
	second = Double(y) 
	list.append(first)
	list.append(second)

print len(list)
RocCurveJApplet.showCurveWindow(list)