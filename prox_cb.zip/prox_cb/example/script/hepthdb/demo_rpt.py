from kdl.prox.dbmgr import DataTypeEnum
from kdl.prox.script import EstItemModelAttr
from kdl.prox.gui2 import RocCurveJApplet

proxdb = prox.getProxDB()
rootContainer = proxdb.getRootContainer()

# EstItemModelAttr: item, attr, isObj, isContinuous
inputItemAttrs = [ \
    EstItemModelAttr('Author', 'author_avg_is_pub_phys_b_by_1996', 1, 1), \
    EstItemModelAttr('CitedPaper', 'is_pub_phys_b_by_1996', 1, 0), \
    EstItemModelAttr('Paper', 'num_pages', 1, 1), \
    EstItemModelAttr('PastPaper', 'paper_citations_out', 1, 1), \
	]

maxDepth = 6
rptPval = 0.05 / float(len(inputItemAttrs))
thresholds = 10
modelName = 'm'
xmlFileName = '/tmp/rpt_' + modelName + '_1996.xml'

# the label for each subgraph
classLabelName = 'is_pub_phys_b'
classLabel = EstItemModelAttr('Paper', classLabelName, 1, 0)

# the output predicted attribute
predictionsAttrName = classLabelName + ':rpt_prediction'

# container
trainColName = '1996-paper-citations-3d-phys-b-d'
testColName = '1997-paper-citations-3d-phys-b-d'
trainContainer = rootContainer.getChild(trainColName)
testContainer = rootContainer.getChild(testColName)

#
# cleanup attributes
#

#prox.log.info('Deleting precalculated features')
#trainContainer.getSubgraphAttrs().deleteAttributesWithPrefix("rpt")
#testContainer.getSubgraphAttrs().deleteAttributesWithPrefix("rpt")
#prox.getProxDB().getObjectAttrs().deleteAttributesWithPrefix("rpt")

prox.log.info('Deleting all temp model attributes')
trainContainer.getSubgraphAttrs().deleteAttributesWithPrefix("model")
testContainer.getSubgraphAttrs().deleteAttributesWithPrefix("model")
prox.getProxDB().getObjectAttrs().deleteAttributesWithPrefix(predictionsAttrName)
#trainContainer.getSubgraphAttrs().deleteAttribute("rpt_temp")

prox.log.info('Check existing subgraphs attributes')
existingAttrs = trainContainer.getSubgraphAttrs().getAttributeNames()
for i in range(len(existingAttrs)):
    prox.log.info(existingAttrs[i])
existingAttrs = testContainer.getSubgraphAttrs().getAttributeNames()
for i in range(len(existingAttrs)):
    prox.log.info(existingAttrs[i])
#existingAttrs = prox.getProxDB().getObjectAttrs().getAttributeNames()
#for i in range(len(existingAttrs)):
#    prox.log.info(existingAttrs[i])

# --------------------------------

prox.log.info("***Begin RPT section of python script***")

# instantiate the model
rpt = prox.instantiateRPT(modelName, rptPval, maxDepth, thresholds)

# induce the tree
prox.log.info("inducing model with " + trainColName)
rpt.induceModel(trainContainer, classLabel, inputItemAttrs)

# apply the model to the test set
prox.log.info("applying model on " + testColName)
rpt.applyModel(testContainer)

# output some xml.
rpt.saveAsXML(xmlFileName)

acc = rpt.accuracy()
prox.log.info("accuracy = " + str(acc))

# write out predictions
#prox.log.info("writing out predictions to " + predictionsAttrName)
#rpt.writePredictions(predictionsAttrName)

# do ROC curve
#prox.log.info("plotting ROC curve")
#points = rpt.genRocPoints("1")
#RocCurveJApplet.showCurveWindow(points)


