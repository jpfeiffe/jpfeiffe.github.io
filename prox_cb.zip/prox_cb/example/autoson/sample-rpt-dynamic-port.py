
from kdl.prox.dbmgr import DataTypeEnum
from kdl.prox.script import EstItemModelAttr
from kdl.prox.old.model.estimators import SetEstimatorTypeEnum
import sys

proxdb = prox.getProxDB()
args = prox.getArgs()
graphSize = int(args[0])
trainingSetSize = int(args[1])
noise = args[2]
fold = int(args[3])

print "**graphSize %d trainingSetSize %d noise %s fold %d" % (graphSize, trainingSetSize, noise, fold)

rootContainer = proxdb.getRootContainer()

# EstItemModelAttr: item, attr, isObj, isContinuous
inputItemAttrs = [ \
		EstItemModelAttr('core', 'objectType', 1, 0), \
		EstItemModelAttr('A', 'objectType', 1, 0), \
		EstItemModelAttr('B', 'objectType', 1, 0), \
		EstItemModelAttr('C', 'objectType', 1, 0), \
		EstItemModelAttr('D', 'objectType', 1, 0), \
		EstItemModelAttr('E', 'objectType', 1, 0), \
		EstItemModelAttr('F', 'objectType', 1, 0), \
		EstItemModelAttr('G', 'objectType', 1, 0), \
		EstItemModelAttr('H', 'objectType', 1, 0), \
		EstItemModelAttr('I', 'objectType', 1, 0), \
		EstItemModelAttr('a', 'linkType', 0, 0), \
		EstItemModelAttr('b', 'linkType', 0, 0), \
		EstItemModelAttr('c', 'linkType', 0, 0), \
		EstItemModelAttr('d', 'linkType', 0, 0), \
		EstItemModelAttr('e', 'linkType', 0, 0), \
		EstItemModelAttr('f', 'linkType', 0, 0), \
		EstItemModelAttr('g', 'linkType', 0, 0), \
		EstItemModelAttr('h', 'linkType', 0, 0), \
		EstItemModelAttr('i', 'linkType', 0, 0), \
	]

maxDepth = 6
rptPval = 0.05 / float(len(inputItemAttrs))
thresholds = 10
modelName = 'clique'

# the label for each subgraph
classLabelName = 'coreLabel'
classLabel = EstItemModelAttr('core', classLabelName, 1, 0)

# container
suffix = 'cliqueSize 10 graphSize %d trainingSetSize %d noise %s fold %d' % (graphSize, trainingSetSize, noise, fold)
trainColName = 'train ' + suffix
testColName = 'test ' + suffix

trainContainer = rootContainer.getChild(trainColName)
testContainer = rootContainer.getChild(testColName)
rptXmlFileName = '/tmp/rpt_' + modelName + suffix + '.xml'

# cleanup attributes
prox.log.info('Deleting all temp model attributes')
trainContainer.getSubgraphAttrs().deleteAttributesWithPrefix("model")
testContainer.getSubgraphAttrs().deleteAttributesWithPrefix("model")

prox.log.info("***Begin RPT section of python script***")

# instantiate the model
rpt = prox.instantiateRPT(modelName, rptPval, maxDepth, thresholds, 1, 0)

# induce the trees
prox.log.info("inducing model with " + trainColName)
rpt.induceModel(trainContainer, classLabel, inputItemAttrs)

# output some xml
rpt.saveAsXML(rptXmlFileName)

# APPLY RPT
rpt.applyModel(trainContainer)
prox.log.info("RPT train %s ACCURACY %d %d %s: %f" % (modelName, graphSize, trainingSetSize, noise, rpt.accuracy()))
prox.log.info("RPT train %s AUC %d %d %s: %f" % (modelName, graphSize, trainingSetSize, noise, rpt.areaUnderROC("+")))

rpt.applyModel(testContainer)
prox.log.info("RPT test %s ACCURACY %d %d %s: %f" % (modelName, graphSize, trainingSetSize, noise, rpt.accuracy()))
prox.log.info("RPT test %s AUC %d %d %s: %f" % (modelName, graphSize, trainingSetSize, noise, rpt.areaUnderROC("+")))



