import sys

proxdb = prox.getProxDB()
args = prox.getArgs()

fold = args[0]
queryFile = args[1]
containerName = args[2]

newContainerName = containerName + "_fold" + fold
prox.queryGraph(queryFile, newContainerName)

