#!/usr/bin/perl

# first ensure we have the right number of arguments
if ($#ARGV != 0) {
    print "Error: usage: database name\n";
    exit(-1);
}

# the command line arguments is database name
$dbname = $ARGV[0];

# local variables
$user = $ENV{USER};
$my_hostname = $ENV{HOST};
$home = $ENV{HOME};

#######################################################
# SET ME TO BE YOUR PROXDIR
#######################################################
$proxdir = "$home\/projects/proximity/proximity3/";

#######################################################
# first copy the database from the master directory on
# /nfs/windtunnel/scratch/username
# store masters here as it has 250GB of local disk
#######################################################
print "copying database $dbname\n";
# note that the path is different for windtunnel as it is local disk
if ($my_hostname eq "windtunnel.cs.umass.edu") {
    $my_path = "/scratch/$user/";
} else {
    $my_path = "/nfs/windtunnel/scratch/$user/";
}

# print "path is: $my_path\n";

# copy over the files to monet on this disk
$tmpdir = "/Monet/var/MonetDB/dbfarm/$user";
mkdir $tmpdir;

# do the un-tar 
$command = "cd $tmpdir; tar xzf " . $my_path . $dbname . ".tgz ";
system($command);

$fulldbname = "$user\_$dbname";

# first delete anything in the target directory
system("cd /Monet/var/MonetDB/dbfarm/; rm -rf $fulldbname");

# now move the files over

system("cd $tmpdir;mv $dbname ../$fulldbname");

# remove the temp directory
rmdir $tmpdir;
print "done copying the database to $fulldbname\n";

#######################################################
# now that the database is copied, start the appropriate mserver
#######################################################
print "starting database server...\n";
system("Mserver --dbname $fulldbname $proxdir\/example/autoson/init-mserver\.mil &");

# note that the sleep is necessary so that the server has time to start
sleep 3;

#######################################################
# RUN EXPERIMENT HERE - put your experiment here
#######################################################
$propfile = "$proxdir\/example/autoson/hep.prop";
$queryfile = "$proxdir\/example/queries/hep_th/journals_more_bad_than_good_papers.xml";
$containerName = "bad_journals";
$command = "java kdl.prox.app.Query $propfile $queryfile $containerName false true";
print "$command";
system("$command");

#######################################################
# cleanup after ourselves - kill the mserver
#######################################################
print "killing datbase server...\n";
$my_pid = get_proc_pid($fulldbname, "MonetServer", $user);
system("kill -9 $my_pid");
print "killed pid $my_pid. exiting\n";


#######################################################
# copy the database files back to scratch
# comment this out if you don't want to copy back out 
# to the master dir on scratch
#######################################################
print "copying database $fulldbname\n";

# copy over the files from db to scratch
$command = "cd /Monet/var/MonetDB/dbfarm/; tar czf $my_path\/$fulldbname\.tgz $fulldbname";
system($command);


#######################################################
# Helper functions
#######################################################
# find the pid for the specified process for this user
sub get_proc_pid {
    my($dbname, $proc, $my_user) = @_;

    $results = `ps axww | grep $proc | grep -v grep | grep $dbname | grep $my_user`;
    @results = split /\n/, $results;
    foreach $line (@results) {
	print "$line\n";

		if ($line =~ /\s*(\d+)\s.*/) {
			$my_pid = $1;
			#	print "my_pid is $my_pid\n";
		}
    }
    return $my_pid;
}

