#!/usr/bin/perl

# first ensure we have the right number of arguments
if ($#ARGV != 5) {
    print "Error: usage: <database> <graphSize> <trainingSetSize> <noise> <fold> <port-base>\n";
    exit(-1);
}

# the command line arguments are database name and fold
$dbname = $ARGV[0];
$graphSize = $ARGV[1];
$trainingSetSize = $ARGV[2];
$noise = $ARGV[3];
$fold = $ARGV[4];
$port = $ARGV[5] + $fold;

print "graphSize $graphSize trainingSetSize $trainingSetSize ";
print "noise $noise fold $fold\n";

# local variables
$user = $ENV{USER};
$my_hostname = $ENV{HOST};
$home = $ENV{HOME};

#######################################################
# SET ME TO BE YOUR PROXDIR
#######################################################
$proxdir = "$home\/projects/proximity/proximity3/";

#######################################################
# first copy the database from the master directory on
# /nfs/windtunnel/scratch/username
# store masters here as it has 250GB of local disk
#######################################################
print "copying database $dbname\n";
# note that the path is different for windtunnel as it is local disk
if ($my_hostname eq "windtunnel-cs-umass-edu") {
    $my_path = "/scratch/$user/";
} else {
    $my_path = "/nfs/windtunnel/scratch/$user/";
}

# print "path is: $my_path\n";

# copy over the files to monet on this disk
$tmpdir = "/Monet/var/MonetDB/dbfarm/$user\_port$port";
mkdir $tmpdir;

# do the un-tar 
$command = "cd $tmpdir; tar xzf " . $my_path . $dbname . ".tgz ";
system($command);

$fulldbname = "$user\_$dbname\_port$port";

# first delete anything in the target directory
system("cd /Monet/var/MonetDB/dbfarm/; rm -rf $fulldbname");

# now move the files over

system("cd $tmpdir;mv $dbname ../$fulldbname");

# remove the temp directory
rmdir $tmpdir;
print "done copying the database to $fulldbname\n";

#######################################################
# now that the database is copied, start the appropriate mserver
#######################################################
print "starting database server...\n";
$ENV{MONETPORT} = $port;
system("Mserver --dbname $fulldbname $proxdir\/example/autoson/init-mserver-dynport\.mil &");

# note that the sleep is necessary so that the server has time to start
sleep 3;

#######################################################
# RUN EXPERIMENT HERE - put your experiment here
#######################################################
$command = "java -Xms50m -Xmx550m kdl.prox.app.PythonScript localhost:$port sample-dynamic-rpt.py $graphSize $trainingSetSize $noise $fold";
print "$command";
system("$command");

#######################################################
# cleanup after ourselves - kill the mserver
#######################################################
print "killing datbase server...\n";
$my_pid = get_proc_pid($fulldbname, "MonetServer", $user);
system("kill -9 $my_pid");
print "killed pid $my_pid. exiting\n";


#######################################################
# copy the database files back to scratch
# comment this out if you don't want to copy back out
# to the master dir on scratch
#######################################################
print "copying database $fulldbname\n";

# copy over the files from db to scratch
$command = "cd /Monet/var/MonetDB/dbfarm/; tar czf $my_path\/$fulldbname\.tgz $fulldbname";
system($command);


#######################################################
# Helper functions
#######################################################
# find the pid for the specified process for this user
sub get_proc_pid {
    my($dbname, $proc, $my_user) = @_;

    $results = `ps axww | grep $proc | grep -v grep | grep $dbname | grep $my_user`;
    @results = split /\n/, $results;
    foreach $line (@results) {
	print "$line\n";

		if ($line =~ /\s*(\d+)\s.*/) {
			$my_pid = $1;
			#	print "my_pid is $my_pid\n";
		}
    }
    return $my_pid;
}

