./Evaluation DVD      nb > ./DVD_nb.out      &
./Evaluation Music    nb > ./Music_nb.out    &

./Evaluation DVD      lr > ./DVD_lr.out      &
./Evaluation Music    lr > ./Music_lr.out    &

wait
