/*
 * Demonstrates that Gibbs Sampling samples from a bad part of the space.  5 trials of RNB/RLR
 * is used to demonstrate
    Copyright (C) 2014 Joseph Pfeiffer

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "Headers/RNB_EM.hpp"
#include "Headers/RLR_EM.hpp"
#include "Headers/Helpers.hpp"
#include <iostream>
#include <iomanip>


int main(int argc, char* argv[]) {
	std::cout << "STARTING" << std::endl;
	srand(0);
	char *path;
	std::string base_filename("./");


	std::string dataset_name;
	std::string out_file_prefix;

	if (argc <= 1) {
		std::cout << "Must Name Dataset! (Arg 1)" << std::endl;
		exit(0);
	}
	else {
		dataset_name = base_filename + "/Data/" + std::string(argv[1]);
		out_file_prefix = std::string(argv[1]);
	}


	std::string outdir = base_filename + "/Outputs/" + out_file_prefix;

	int pos_num;
	RNB expert;
	std::cout << "Dataset: " << dataset_name << std::endl;
	std::cout << "OutDirectory: " << outdir << std::endl;
	expert.ReadFile(dataset_name);

	std::cout << "NUM Vertices: " << expert.num_vertices() << std::endl;
	std::cout << "NUM Edges: " << expert.num_edges() << std::endl;
	std::cout << "NUM Attributes: " << expert.getNumberAttr() << std::endl;
	std::cout << "Correlation: " << expert.ComputeLabelCorrelation() << std::endl;

	YS ys = expert.getYS();
	YS unlabeled_ys = YS();
	std::vector<int> labeled_items_vector = expert.getLabeledInstances();


	YS::iterator y_it;
	double sum = 0;
	for(y_it = ys.begin(); y_it != ys.end(); y_it++) {
		sum += y_it->second;
		unlabeled_ys[y_it->first] = -1;
	}

	pos_num = sum;
	std::cout << "Proportion Positive: " << sum / expert.num_vertices() << std::endl;
	expert.learnModel();

	int trials = 100;
	double label_percentage = .1;
	int iterations = 1000;

	std::vector<std::vector<std::vector<int> > > positives;
	std::vector<std::vector<std::vector<int> > > negatives;

	std::vector<Classifier*> Methods;
	std::vector<std::string> names;
	Classifier* method;
	NB* nb;
	RNB* rnb;
	RNB_EM* rnb_em;
	LR* lr;
	RLR* rlr;
	RLR_EM* rlr_em;

	std::map<int,double> true_conditionals;

	//--------------------- ADDING METHODS -------------------------
	rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RNB_EM::R_EM, RNB_EM::GIBBS);
	rnb_em->setXS(expert.getXS());
	rnb_em->setMethodName("RNB (1)");
	Methods.push_back(rnb_em);

	rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RNB_EM::R_EM, RNB_EM::GIBBS);
	rnb_em->setXS(expert.getXS());
	rnb_em->setMethodName("RNB (2)");
	Methods.push_back(rnb_em);

	rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RNB_EM::R_EM, RNB_EM::GIBBS);
	rnb_em->setXS(expert.getXS());
	rnb_em->setMethodName("RNB (3)");
	Methods.push_back(rnb_em);

	rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RNB_EM::R_EM, RNB_EM::GIBBS);
	rnb_em->setXS(expert.getXS());
	rnb_em->setMethodName("RNB (4)");
	Methods.push_back(rnb_em);

	rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RNB_EM::R_EM, RNB_EM::GIBBS);
	rnb_em->setXS(expert.getXS());
	rnb_em->setMethodName("RNB (5)");
	Methods.push_back(rnb_em);


	rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RLR_EM::R_EM, RLR_EM::GIBBS);
	rlr_em->setXS(expert.getXS());
	rlr_em->setMethodName("RLR (1)");
	Methods.push_back(rlr_em);

	rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RLR_EM::R_EM, RLR_EM::GIBBS);
	rlr_em->setXS(expert.getXS());
	rlr_em->setMethodName("RLR (2)");
	Methods.push_back(rlr_em);

	rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RLR_EM::R_EM, RLR_EM::GIBBS);
	rlr_em->setXS(expert.getXS());
	rlr_em->setMethodName("RLR (3)");
	Methods.push_back(rlr_em);

	rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RLR_EM::R_EM, RLR_EM::GIBBS);
	rlr_em->setXS(expert.getXS());
	rlr_em->setMethodName("RLR (4)");
	Methods.push_back(rlr_em);

	rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, iterations, RLR_EM::R_EM, RLR_EM::GIBBS);
	rlr_em->setXS(expert.getXS());
	rlr_em->setMethodName("RLR (5)");
	Methods.push_back(rlr_em);


	int total = pos_num;
	Y a_yval;
	int a_chosen;

	// Initialize to random starting node -- get its values and neighbors
	std::vector<int> neighbors_vec;
	std::unordered_set<int> neighbors_set;

	int num_labeled = expert.num_vertices()*label_percentage;

	for (int m = 0; m < Methods.size(); m++) {
		Methods[m]->setYS(unlabeled_ys);
		Methods[m]->setXS(expert.getXS());
		Methods[m]->clearUnlabeledInstances(labeled_items_vector);

		// Add new values
		for (int found = 0; found < num_labeled; found++) {
			int cur_method_val = 0;
			a_yval = 0;
			int neighbors_size = -1;
			while (cur_method_val != -1)
			{
				a_chosen = ((double)expert.num_vertices()*rand()) / RAND_MAX;
				a_yval = expert.getY(a_chosen);
				cur_method_val = Methods[m]->getY(a_chosen);
			}

			// Add to the models
			Methods[m]->setY(a_chosen, a_yval);
		}

		std::cout << "Method: " << Methods[m]->getMethodName() << "\tSizes: Labeled-" << Methods[m]->getLabeledInstances().size() << ", Unlabeled-" << Methods[m]->getUnlabeledInstances().size() << std::endl;
		positives.push_back(std::vector<std::vector<int> >());
		negatives.push_back(std::vector<std::vector<int> >());
		names.push_back(Methods[m]->getMethodName());


		Methods[m]->learnModel();

		positives[m].push_back(Methods[m]->getTotalPositives());
		negatives[m].push_back(Methods[m]->getTotalNegatives());
	}
	std::cout << std::endl;


	std::cout << "Start Writeout" << std::endl;
	Helpers::WriteoutResults(outdir + "_compare_positives_mean.txt", outdir + "_compare_positives_stderr.txt", names, 1, iterations, positives);
	Helpers::WriteoutResults(outdir + "_compare_negatives_mean.txt", outdir + "_compare_negatives_stderr.txt", names, 1, iterations, negatives);
	std::cout << "End Writeout" << std::endl;

	std::cout << std::endl;
	return 0;
}
