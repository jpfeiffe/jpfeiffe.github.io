/*
 * Evaluation.cpp
 * Main tester -- produces the error, parameter variance and eigenvalues
    Copyright (C) 2014 Joseph Pfeiffer

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "Headers/RNB_EM.hpp"
#include "Headers/RLR_EM.hpp"
#include "Headers/Helpers.hpp"
#include <iostream>
#include <iomanip>


int main(int argc, char* argv[]) {
	std::cout << "STARTING" << std::endl;
	srand(0);
	char *path;
	std::string base_filename("./");


	std::string dataset_name;
	std::string out_file_prefix;

	if (argc <= 1) {
		std::cout << "Must Name Dataset! (Arg 1)" << std::endl;
		exit(0);
	}
	else {
		dataset_name = base_filename + "/Data/" + std::string(argv[1]);
		out_file_prefix = std::string(argv[1]);
	}

	if (argc > 2) {
		if (std::string(argv[2]) == "nb")
			out_file_prefix.append("_nb_");
		else if (std::string(argv[2]) == "lr")
			out_file_prefix.append("_lr_");
		else {
			std::cout << "Second Argument must be 'nb' or 'lr'" << std::endl;
			exit(0);
		}
	}
	else {
		std::cout << "Second Argument must be 'nb' or 'lr'" << std::endl;
		exit(0);
	}
	std::string outdir = base_filename + "/Outputs/" + out_file_prefix;

	int pos_num;
	RNB expert;
	std::cout << "Dataset: " << dataset_name << std::endl;
	std::cout << "OutDirectory: " << outdir << std::endl;
	expert.ReadFile(dataset_name);

	std::cout << "NUM Vertices: " << expert.num_vertices() << std::endl;
	std::cout << "NUM Edges: " << expert.num_edges() << std::endl;
	std::cout << "NUM Attributes: " << expert.getNumberAttr() << std::endl;
	std::cout << "Correlation: " << expert.ComputeLabelCorrelation() << std::endl;

	YS ys = expert.getYS();
	YS unlabeled_ys = YS();
	std::vector<int> labeled_items_vector = expert.getLabeledInstances();


	YS::iterator y_it;
	double sum = 0;
	for(y_it = ys.begin(); y_it != ys.end(); y_it++) {
		sum += y_it->second;
		unlabeled_ys[y_it->first] = -1;
	}

	pos_num = sum;
	std::cout << "Proportion Positive: " << sum / expert.num_vertices() << std::endl;
	expert.learnModel();

	int trials = 100;
//	std::vector<double> label_percentages = {.001, .0025, .005, .0075, .01, .025, .05, .075, .1, .2, .3, .4, .5, .6, .7, .8, .9};
	std::vector<double> label_percentages = { .05, .1, .2, .3, .4, .5, .6, .7, .8, .9};
//	std::vector<double> label_percentages = { .1, .25, .5, .75};
	std::vector<std::vector<std::vector<double> > > loss01;
	std::vector<std::vector<std::vector<double> > > mae;
	std::vector<std::vector<std::vector<double> > > bae;
	std::vector<std::vector<std::vector<double> > > within_iteration_eigenvalue_0;
	std::vector<std::vector<std::vector<double> > > within_iteration_eigenvalue_1;
	std::vector<std::vector<std::vector<double> > > cross_iteration_eigenvalue_0;
	std::vector<std::vector<std::vector<double> > > cross_iteration_eigenvalue_1;
	std::vector<std::vector<std::vector<double> > > perfect_iteration_eigenvalue_0;
	std::vector<std::vector<std::vector<double> > > perfect_iteration_eigenvalue_1;
	std::vector<std::vector<std::vector<double> > > converged_iteration_values_0;
	std::vector<std::vector<std::vector<double> > > converged_iteration_values_1;
	std::vector<std::vector<std::vector<double> > > param_variance;

	std::vector<Classifier*> Methods;
	std::vector<std::string> names;
	Classifier* method;
	NB* nb;
	RNB* rnb;
	RNB_EM* rnb_em;
	LR* lr;
	RLR* rlr;
	RLR_EM* rlr_em;

	std::map<int,double> true_conditionals;

	if (argc > 2 and std::string(argv[2]) == "nb") {
		// -------------------EXPERT (Not considered)
		rnb = new RNB(expert.getGraph(), expert.getNumberAttr());
		rnb->setXS(expert.getXS());
		rnb->setYS(expert.getYS());
		rnb->setLabeledInstances(labeled_items_vector);
		rnb->learnModel();
		rnb->computeLabeledConditionals();
		true_conditionals = rnb->GetConditionals();

		//--------------------- ADDING METHODS -------------------------
		nb = new NB(expert.getGraph(), expert.getNumberAttr());
		nb->setXS(expert.getXS());
		nb->setMethodName(nb->getMethodName());
		nb->SetTrueConditionals(true_conditionals);
		Methods.push_back(nb);

		rnb = new RNB(expert.getGraph(), expert.getNumberAttr());
		rnb->setXS(expert.getXS());
		rnb->setMethodName("RNB (IND)");
		rnb->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb);

		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1, 100, RNB_EM::R_EM, RNB_EM::GIBBS);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("RNB (CI)");
		rnb_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb_em);


		/*  UNCOMMENT FOR MF_APPROX Testing of R_EM */
		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 10, 100, RNB_EM::R_EM, RNB_EM::MF_APPROX);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-EM (10-VMF)");
		Methods.push_back(rnb_em);

		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 11, 100, RNB_EM::R_EM, RNB_EM::MF_APPROX);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-EM (11-VMF)");
		Methods.push_back(rnb_em);

		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 10, 100, RNB_EM::R_EM, RNB_EM::GIBBS);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-EM (10-Gibbs)");
		rnb_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb_em);
//
		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 11, 100, RNB_EM::R_EM, RNB_EM::GIBBS);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-EM (11-Gibbs)");
		rnb_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb_em);

		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 900, 1, RNB_EM::R_SEM, RNB_EM::GIBBS);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-SEM");
		rnb_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb_em);

//		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 900, 1, RNB_EM::R_SEM, RNB_EM::GIBBS);
//		rnb_em->setLastInit(true);
//		rnb_em->setXS(expert.getXS());
//		rnb_em->setMethodName("R-SEM (Last Init)");
//		rnb_em->SetTrueConditionals(true_conditionals);
//		Methods.push_back(rnb_em);

		rnb_em = new RNB_EM(expert.getGraph(), expert.getNumberAttr(), 1000, 1, RNB_EM::R_DA, RNB_EM::GIBBS);
		rnb_em->setXS(expert.getXS());
		rnb_em->setMethodName("R-DA");
		rnb_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rnb_em);
	}




	else if (argc > 2 and std::string(argv[2]) == "lr") {
		// -------------------EXPERT (Not considered)
		rlr = new RLR(expert.getGraph(), expert.getNumberAttr(), LR::NONE);
		rlr->setXS(expert.getXS());
		rlr->setYS(expert.getYS());
		rlr->setLabeledInstances(labeled_items_vector);
		rlr->learnModel();
		rlr->computeLabeledConditionals();
		true_conditionals = rlr->GetConditionals();


		lr = new LR(expert.getGraph(), expert.getNumberAttr(), LR::NONE);
		lr->setXS(expert.getXS());
		lr->setMethodName(lr->getMethodName());
		lr->SetTrueConditionals(true_conditionals);
		Methods.push_back(lr);

		rlr = new RLR(expert.getGraph(), expert.getNumberAttr(), LR::NONE);
		rlr->setXS(expert.getXS());
		rlr->setMethodName("RLR (IND)");
		rlr->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr);

		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1, 100, RLR_EM::R_EM, RLR_EM::GIBBS);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("RLR (CI)");
		rlr_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr_em);

		//		/*  UNCOMMENT FOR MF_APPROX Testing of R_EM */
		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 10, 100, RLR_EM::R_EM, RLR_EM::MF_APPROX);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-EM (10-VMF)");
		Methods.push_back(rlr_em);

		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 11, 100, RLR_EM::R_EM, RLR_EM::MF_APPROX);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-EM (11-VMF)");
		Methods.push_back(rlr_em);

		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 10, 100, RLR_EM::R_EM, RLR_EM::GIBBS);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-EM (10-Gibbs)");
		rlr_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr_em);

		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 11, 100, RLR_EM::R_EM, RLR_EM::GIBBS);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-EM (11-Gibbs)");
		rlr_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr_em);

		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 900, 1, RLR_EM::R_SEM, RLR_EM::GIBBS);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-SEM");
		rlr_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr_em);

//		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 900, 1, RLR_EM::R_SEM, RLR_EM::GIBBS);
//		rlr_em->setLastInit(true);
//		rlr_em->setXS(expert.getXS());
//		rlr_em->setMethodName("R-SEM (Last Init)");
//		rlr_em->SetTrueConditionals(true_conditionals);
//		Methods.push_back(rlr_em);
//
		rlr_em = new RLR_EM(expert.getGraph(), expert.getNumberAttr(), 1000, 1, RLR_EM::R_DA, RLR_EM::GIBBS);
		rlr_em->setXS(expert.getXS());
		rlr_em->setMethodName("R-DA");
		rlr_em->SetTrueConditionals(true_conditionals);
		Methods.push_back(rlr_em);
//
//
	}

	else {
		std::cout << "ERROR: Invalid Algorithm Choices" << std::endl;
		exit(0);
	}


	for (int m = 0; m < Methods.size(); m++) {
		loss01.push_back(std::vector<std::vector<double> >());
		mae.push_back(std::vector<std::vector<double> >());
		bae.push_back(std::vector<std::vector<double> >());
		within_iteration_eigenvalue_0.push_back(std::vector<std::vector<double> >());
		within_iteration_eigenvalue_1.push_back(std::vector<std::vector<double> >());
		cross_iteration_eigenvalue_0.push_back(std::vector<std::vector<double> >());
		cross_iteration_eigenvalue_1.push_back(std::vector<std::vector<double> >());
		perfect_iteration_eigenvalue_0.push_back(std::vector<std::vector<double> >());
		perfect_iteration_eigenvalue_1.push_back(std::vector<std::vector<double> >());
		converged_iteration_values_0.push_back(std::vector<std::vector<double> >());
		converged_iteration_values_1.push_back(std::vector<std::vector<double> >());
		param_variance.push_back(std::vector<std::vector<double> >());
		names.push_back(Methods[m]->getMethodName());
	}

	for (int trial = 0; trial < trials; trial++) {

		for(int m = 0; m < Methods.size(); m++) {
			loss01[m].push_back(std::vector<double>());
			mae[m].push_back(std::vector<double>());
			bae[m].push_back(std::vector<double>());
			within_iteration_eigenvalue_0[m].push_back(std::vector<double>());
			within_iteration_eigenvalue_1[m].push_back(std::vector<double>());
			cross_iteration_eigenvalue_0[m].push_back(std::vector<double>());
			cross_iteration_eigenvalue_1[m].push_back(std::vector<double>());
			perfect_iteration_eigenvalue_0[m].push_back(std::vector<double>());
			perfect_iteration_eigenvalue_1[m].push_back(std::vector<double>());
			converged_iteration_values_0[m].push_back(std::vector<double>());
			converged_iteration_values_1[m].push_back(std::vector<double>());
			param_variance[m].push_back(std::vector<double>());

			Methods[m]->setYS(unlabeled_ys);
			Methods[m]->setXS(expert.getXS());
			Methods[m]->clearUnlabeledInstances(labeled_items_vector);
		}

		int total = pos_num;
		Y a_yval;
		int a_chosen;

		// Initialize to random starting node -- get its values and neighbors
		int found = 0;

		std::vector<int> neighbors_vec;
		std::unordered_set<int> neighbors_set;

		for (int labeled_ind = 0; labeled_ind < label_percentages.size(); labeled_ind++)
		{
			std::cout << "Trial:\t" << trial << "\tLabel Percent:\t" << label_percentages[labeled_ind] << std::endl;
			int num_labeled = expert.num_vertices()*label_percentages[labeled_ind];

			// Add new values
			for (; found < num_labeled; found++) {
				int cur_method_val = 0;
				a_yval = 0;
				int neighbors_size = -1;
				while (cur_method_val != -1)
				{
					a_chosen = ((double)expert.num_vertices()*rand()) / RAND_MAX;
					a_yval = expert.getY(a_chosen);
					cur_method_val = Methods[0]->getY(a_chosen);
				}

				// Add to the models
				for (int m = 0; m < Methods.size(); m++) {
					Methods[m]->setY(a_chosen, a_yval);
				}
			}

			for (int m = 0; m < Methods.size(); m++) {
				std::cout << "Method: " << Methods[m]->getMethodName() << "\tSizes: Labeled-" << Methods[m]->getLabeledInstances().size() << ", Unlabeled-" << Methods[m]->getUnlabeledInstances().size() << std::endl;

				Methods[m]->learnModel();
				Methods[m]->computeConditionals();
				std::map<int,double> conditionals = Methods[m]->GetConditionals();

				loss01[m][trial].push_back((expert.Compute01Loss(conditionals)));
				mae[m][trial].push_back((expert.ComputeMAE(conditionals)));
				bae[m][trial].push_back((expert.ComputeBAE(conditionals)));
				param_variance[m][trial].push_back(Methods[m]->getParameterVariance());
				within_iteration_eigenvalue_0[m][trial].push_back(Methods[m]->computeWithinIterationJacobianMaxEigenvalue(0));
				within_iteration_eigenvalue_1[m][trial].push_back(Methods[m]->computeWithinIterationJacobianMaxEigenvalue(1));
				cross_iteration_eigenvalue_0[m][trial].push_back(Methods[m]->computeCrossIterationJacobianMaxEigenvalue(0));
				cross_iteration_eigenvalue_1[m][trial].push_back(Methods[m]->computeCrossIterationJacobianMaxEigenvalue(1));
				perfect_iteration_eigenvalue_0[m][trial].push_back(Methods[m]->computePerfectIterationJacobianMaxEigenvalue(0));
				perfect_iteration_eigenvalue_1[m][trial].push_back(Methods[m]->computePerfectIterationJacobianMaxEigenvalue(1));
				converged_iteration_values_0[m][trial].push_back(Methods[m]->computeConvergedValues(0));
				converged_iteration_values_1[m][trial].push_back(Methods[m]->computeConvergedValues(1));
			}
			std::cout << std::endl;
		}
		std::cout << "Start Writeout" << std::endl;
		Helpers::WriteoutResults(outdir + "compare_01loss_mean.txt", outdir + "compare_01loss_stderr.txt", names, trial+1, label_percentages, loss01);
		Helpers::WriteoutResults(outdir + "compare_mae_mean.txt", outdir + "compare_mae_stderr.txt", names, trial+1, label_percentages, mae);
		Helpers::WriteoutResults(outdir + "compare_bae_mean.txt", outdir + "compare_bae_stderr.txt", names, trial+1, label_percentages, bae);

		Helpers::WriteoutResults(outdir + "compare_withineigens_mean.txt", outdir + "compare_withineigens_stderr.txt", names, trial+1, label_percentages, within_iteration_eigenvalue_0, within_iteration_eigenvalue_1);
		Helpers::WriteoutDiffResults(outdir + "compare_withineigens_diff_mean.txt", outdir + "compare_withineigens_diff_stderr.txt", names, trial+1, label_percentages, within_iteration_eigenvalue_0, within_iteration_eigenvalue_1);
		Helpers::WriteoutMaxResults(outdir + "compare_withineigens_max_mean.txt", outdir + "compare_withineigens_max_stderr.txt", names, trial+1, label_percentages, within_iteration_eigenvalue_0, within_iteration_eigenvalue_1);
		Helpers::WriteoutMinResults(outdir + "compare_withineigens_min_mean.txt", outdir + "compare_withineigens_min_stderr.txt", names, trial+1, label_percentages, within_iteration_eigenvalue_0, within_iteration_eigenvalue_1);

		Helpers::WriteoutResults(outdir + "compare_crosseigens_mean.txt", outdir + "compare_crosseigens_stderr.txt", names, trial+1, label_percentages, cross_iteration_eigenvalue_0, cross_iteration_eigenvalue_1);
		Helpers::WriteoutDiffResults(outdir + "compare_crosseigens_diff_mean.txt", outdir + "compare_crosseigens_diff_stderr.txt", names, trial+1, label_percentages, cross_iteration_eigenvalue_0, cross_iteration_eigenvalue_1);
		Helpers::WriteoutMaxResults(outdir + "compare_crosseigens_max_mean.txt", outdir + "compare_crosseigens_max_stderr.txt", names, trial+1, label_percentages, cross_iteration_eigenvalue_0, cross_iteration_eigenvalue_1);
		Helpers::WriteoutMinResults(outdir + "compare_crosseigens_min_mean.txt", outdir + "compare_crosseigens_min_stderr.txt", names, trial+1, label_percentages, cross_iteration_eigenvalue_0, cross_iteration_eigenvalue_1);

		Helpers::WriteoutResults(outdir + "compare_perfecteigens_mean.txt", outdir + "compare_perfecteigens_stderr.txt", names, trial+1, label_percentages, perfect_iteration_eigenvalue_0, perfect_iteration_eigenvalue_1);
		Helpers::WriteoutDiffResults(outdir + "compare_perfecteigens_diff_mean.txt", outdir + "compare_perfecteigens_diff_stderr.txt", names, trial+1, label_percentages, perfect_iteration_eigenvalue_0, perfect_iteration_eigenvalue_1);
		Helpers::WriteoutMaxResults(outdir + "compare_perfecteigens_max_mean.txt", outdir + "compare_perfecteigens_max_stderr.txt", names, trial+1, label_percentages, perfect_iteration_eigenvalue_0, perfect_iteration_eigenvalue_1);
		Helpers::WriteoutMinResults(outdir + "compare_perfecteigens_min_mean.txt", outdir + "compare_perfecteigens_min_stderr.txt", names, trial+1, label_percentages, perfect_iteration_eigenvalue_0, perfect_iteration_eigenvalue_1);

		Helpers::WriteoutResults(outdir + "compare_convergedvals_mean.txt", outdir + "compare_convergedvals_stderr.txt", names, trial+1, label_percentages, converged_iteration_values_0, converged_iteration_values_1);
		Helpers::WriteoutDiffResults(outdir + "compare_convergedvals_diff_mean.txt", outdir + "compare_convergedvals_diff_stderr.txt", names, trial+1, label_percentages, converged_iteration_values_0, converged_iteration_values_1);
		Helpers::WriteoutMaxResults(outdir + "compare_convergedvals_max_mean.txt", outdir + "compare_convergedvals_max_stderr.txt", names, trial+1, label_percentages, converged_iteration_values_0, converged_iteration_values_1);
		Helpers::WriteoutMinResults(outdir + "compare_convergedvals_min_mean.txt", outdir + "compare_convergedvals_min_stderr.txt", names, trial+1, label_percentages, converged_iteration_values_0, converged_iteration_values_1);

		Helpers::WriteoutResults(outdir + "compare_pv_mean.txt", outdir + "compare_pv_stderr.txt", names, trial+1, label_percentages, param_variance);
		std::cout << "End Writeout" << std::endl;
	}
	std::cout << std::endl;
	return 0;
}
