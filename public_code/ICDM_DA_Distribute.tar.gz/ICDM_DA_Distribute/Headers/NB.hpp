/*
 * NB.hpp
 */

#ifndef NB_HPP_
#define NB_HPP_

#include "Classifier.hpp"
#include "Binary.hpp"

class NB : public Classifier {
protected:
	std::vector<Binary> x_conds;

	double posprior;
	double prior_weight;
	void normalizeConds();

public:
	NB(eigen_matrix new_graph=eigen_matrix(), int num_attr=2)
	: Classifier(new_graph, num_attr)
	{
		_method_name = "NB";
		for(int i = 0; i < num_attr; i++){
			x_conds.push_back(Binary());
		}
		prior_weight = .5;
		setPriors();
	}

	virtual Classifier* Clone();
	void setPriors();
	virtual void ReadFile(std::string filename)
	{
		Classifier::ReadFile(filename);

		x_conds.clear();
		for(int i = 0; i < _num_attr; i++){
			x_conds.push_back(Binary());
		}
		setPriors();
	}
	void setPriorWeight(double v) {prior_weight = v;}

	virtual double computeVariationalJacobianMaxEigenvalue() {return 0;}
	virtual double computeParameterVariance() {return 0;}

	virtual void learnModel();
	double computeConditional(int v);
	virtual void computeConditionals();
	virtual void computeLabeledConditionals() {}
};


Classifier* NB::Clone()
{
	NB* newnb = new NB(eigen_matrix(graph), _num_attr);
	return newnb;
}

/*
 * Helper for setting the initial values
 */
void NB::setPriors()
{
	posprior = .5;
	for(int i = 0; i < x_conds.size(); i++)
		x_conds[i].setAll(prior_weight);
}

/*
 * helper function to normalize our conditional distributions
 */
void NB::normalizeConds()
{
	for(int i = 0; i < x_conds.size(); i++)
		x_conds[i].normalize();
}

void NB::learnModel()
{
	int samples = 0;

	double pos,total;
	pos = .5;
	total = 1;

	setPriors();

	int v;
	int ylabel;

	for (int v : _labeled_vertices) {
		ylabel = ys[v];

		for(int i = 0; i < xs[v].size(); i++) {
			x_conds[i].increment(ylabel, xs[v][i]);
		}
		if (ylabel == 1) pos++;
		total++;
	}

	normalizeConds();

	posprior = pos/total;
}


double NB::computeConditional(int v)
{
	double posprob = log(posprior);
	double negprob = log(1-posprior);

	for(int i = 0; i < xs[v].size(); i++) {
		posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
		negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
	}

	double prob = exp(posprob) / (exp(posprob) + exp(negprob));
	return prob;
}




void NB::computeConditionals()
{
	conditionals.clear();
	int v;

	double average = 0;
	for (int v : _unlabeled_vertices)
	{
		double posprob = log(posprior);
		double negprob = log(1-posprior);

		for(int i = 0; i < xs[v].size(); i++) {
			posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
			negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
		}

		double prob = exp(posprob) / (exp(posprob) + exp(negprob));
		conditionals[v] = prob;
		average += 0;
	}
	average /= _unlabeled_vertices.size();

	_within_iteration_eigenvalues.clear();
	_within_iteration_eigenvalues.push_back(0);
	_within_iteration_eigenvalues.push_back(0);
	_cross_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.push_back(0);
	_cross_iteration_eigenvalues.push_back(0);
	_perfect_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.push_back(0);
	_perfect_iteration_eigenvalues.push_back(0);
	_converged_values.clear();
	_converged_values.push_back(average);
	_converged_values.push_back(average);
}

#endif /* NB_HPP_ */
