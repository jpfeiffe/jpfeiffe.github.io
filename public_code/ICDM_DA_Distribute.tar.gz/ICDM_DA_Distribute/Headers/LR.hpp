/*
 * LR.hpp
 */

#ifndef LR_HPP_
#define LR_HPP_

#include "Classifier.hpp"
#include "liblinear/linear.h"


class LR : public Classifier {
public:
	enum NORMALIZATION {NONE, ZERO_ONE};
protected:
	model* lr_model;
	parameter param;

	double* _means;
	double* _stds;

	NORMALIZATION _norm;

	virtual void normalize01(feature_node** data, int num_instances);
	virtual void normalize01(feature_node* data);

	virtual void normalize(feature_node** data, int num_instances);
	virtual void normalize(feature_node* data);

	virtual feature_node* featurize(int v);
public:
	LR(eigen_matrix new_graph=eigen_matrix(), int num_attr=2, NORMALIZATION norm = NONE)
	: Classifier(new_graph, num_attr)
	{
		_method_name = "LR";

		// L2R_LR
		param.solver_type = 0;
		param.C = 1;
		param.eps = 0.01; // see setting below
		param.p = 0.1;
		param.nr_weight = 0;
		param.weight_label = NULL;
		param.weight = NULL;

		lr_model = NULL;
		_means = NULL;
		_stds = NULL;
		_norm = norm;
	}

	~LR()
	{
		if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}
		if (_means != NULL) {delete _means; _means = NULL;}
		if (_stds != NULL) {delete _stds; _stds = NULL;}
	}

	void setC(double newC) {param.C = newC;}
	virtual LR* Clone();

	virtual double computeVariationalJacobianMaxEigenvalue() {return 0;}
	virtual double computeParameterVariance() {return 0;}

	virtual void learnModel();

	double computeConditional(int v);

	void computeConditionals();

	virtual void computeLabeledConditionals() {}
	virtual void computeJacobianEigenvalues() {}

};


LR* LR::Clone()
{
	LR* newlr = new LR(graph, _num_attr, _norm);
	return newlr;
}





void LR::normalize01(feature_node** data, int num_instances)
{
	if (_means == NULL) _means = new double[_num_attr];
	if (_stds == NULL) _stds = new double[_num_attr];

	for (int i = 0; i < _num_attr; i++)
	{
		double mean = 0;
		double std = 0;
		for (int j = 0; j < num_instances; j++)
		{
			mean += data[j][i].value;
		}

		// Don't bother if they're all 0s
		if (mean == 0) {_stds[i] = -1; continue;}

		mean /= num_instances;
		for (int j = 0; j < num_instances; j++)
		{
			std += (data[j][i].value - mean)*(data[j][i].value - mean);
		}

		// Don't bother if all the same value
		if (std == 0)  {_stds[i] = -1; continue;}

		std /= (num_instances - 1);
		std = sqrt(std);

		_means[i] = mean;
		_stds[i] = std;
	}

	for (int j = 0; j < num_instances; j++)
	{
		normalize01(data[j]);
	}

}


void LR::normalize01(feature_node* data)
{
	for (int i = 0; i < _num_attr; i++)
	{
		double mean = _means[i];
		double std = _stds[i];

		if (std < 0) {data[i].value = 0; continue;}

		data[i].value = (data[i].value - mean) / std;
	}
}



void LR::normalize(feature_node* data)
{
	if (_norm == ZERO_ONE)
		normalize01(data);
}


void LR::normalize(feature_node** data, int num_instances)
{
	if (_norm == ZERO_ONE)
		normalize01(data, num_instances);
}



feature_node* LR::featurize(int v)
{
	feature_node* feat_array = new feature_node[_num_attr+1];
	for(int i = 0; i < xs[v].size(); i++)
	{
		feat_array[i].index = i+1;
		feat_array[i].value = xs[v][i];
	}

	feat_array[_num_attr].index = -1;
	return feat_array;
}

void LR::learnModel()
{
	std::unordered_set<int> positives;
	std::unordered_set<int> negatives;

	if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}

	int samples = 0;

	problem prob;
	prob.l = _labeled_vertices.size();
	prob.n = this->_num_attr;
	prob.bias = -1;
	prob.y = new double[prob.l];
	prob.x = new feature_node*[prob.l];

	for (int v : _labeled_vertices)
	{
		if (ys[v] == 1) positives.insert(v);
		else negatives.insert(v);
	}

	int ind=0;
	for (int v : negatives)
	{
		prob.y[ind] = ys[v];
		prob.x[ind] = featurize(v);
		ind++;
	}

	for (int v : positives)
	{
		prob.y[ind] = ys[v];
		prob.x[ind] = featurize(v);
		ind++;
	}

	normalize(prob.x, prob.l);
	lr_model = train(&prob, &param);

	for (int i = 0; i < prob.l; i++) {
		delete prob.x[i];
	}

	delete prob.x;
	delete prob.y;
}




double LR::computeConditional(int v)
{
	double prob_estimates[2];
	feature_node* feat_array= featurize(v);
	normalize(feat_array);
	predict_probability(lr_model, feat_array, prob_estimates);
	delete feat_array;
	double prob = prob_estimates[1];
	return prob;
}

void LR::computeConditionals()
{
	conditionals.clear();

	double prob_estimates[2];

	double average = 0;
	for(const int& v : _unlabeled_vertices)
	{
		feature_node* feat_array= featurize(v);
		normalize(feat_array);
		predict_probability(lr_model, feat_array, prob_estimates);
		delete feat_array;
		double prob = prob_estimates[1];
		conditionals[v] = prob;
		average += prob;
	}
	average /= _unlabeled_vertices.size();

	_within_iteration_eigenvalues.clear();
	_within_iteration_eigenvalues.push_back(0);
	_within_iteration_eigenvalues.push_back(0);
	_cross_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.push_back(0);
	_cross_iteration_eigenvalues.push_back(0);
	_perfect_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.push_back(0);
	_perfect_iteration_eigenvalues.push_back(0);
	_converged_values.clear();
	_converged_values.push_back(average);
	_converged_values.push_back(average);

}

#endif /* LR_HPP_ */
