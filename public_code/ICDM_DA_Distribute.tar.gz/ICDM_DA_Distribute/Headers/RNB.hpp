/*
 * RNB.hpp
 *
 *  Created on: Oct 18, 2012
 */

#ifndef RNB_HPP_
#define RNB_HPP_

#include "NB.hpp"
#include <algorithm>
#include <vector>
#include <map>
#include <complex>

class RNB : public NB {
protected:
	Binary y_cond;

	void normalizeConds();
	void setPriors();
public:
	RNB(eigen_matrix ugraph = eigen_matrix(), int num_attr=2)
: 	NB(ugraph, num_attr)
{
		setPriors();
		_method_name = "RNB";
}

	virtual Classifier* Clone();

	void learnModel();

	virtual double computeConditional(int v);

	virtual void computeConditionals();
	virtual void computeLabeledConditionals();

	virtual double computeVariationalJacobianMaxEigenvalue();
};


Classifier* RNB::Clone()
{
	return new RNB(eigen_matrix(graph), _num_attr);
}



void RNB::setPriors()
{
	y_cond.setAll(prior_weight);
	NB::setPriors();
}

double RNB::computeVariationalJacobianMaxEigenvalue()
{
	std::unordered_set<int> into_jacobian;
	into_jacobian.reserve(_unlabeled_vertices.size());
	for(int v : _unlabeled_vertices) {
		// Include edges
		for (int neigh : neighbors(v)) {
			if (_labeled_vertices.find(neigh) == _labeled_vertices.end()) {
				into_jacobian.insert(v);
				break;
			}
		}
	}

	// Current setup is for the binary |U|x|U| matrix
	eigen_col_matrix jacobian(into_jacobian.size()*2, into_jacobian.size()*2);

	// Create a mapping from the unlabeled vertex ids to the jacobian we're using
	std::unordered_map<int, int> unlabeled_j_ids;
	int id = 0;
	for(int v : into_jacobian)
		unlabeled_j_ids[v] = id++;

	// Fill in the Jacobian
	double max_abs_deg, min_abs_deg, maxneigh;
	maxneigh = 0;
	min_abs_deg = 1000;
	max_abs_deg = -1;

	double minlogprob_pos = 0;
	double minlogprob_neg = 0;
	typedef Eigen::Triplet<double> T;
	std::vector<T > tripletList;

	//	y_cond.PrintNormalized();

	for(int v : into_jacobian) {
		// Begin by computing the 'g' function (expectation of the log unnormalized energy)
		// Initial probs
		double posprob = log(posprior);
		double negprob = log(1-posprior);

		// Include attributes
		for(int i=0; i < x_conds.size(); i++) {
			posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
			negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
		}

		// Include edges
		for (int neigh : neighbors(v)) {
			if (_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
				posprob += log(y_cond.getNormalized(1, ys[neigh]));
				negprob += log(y_cond.getNormalized(0, ys[neigh]));
			}
			// This is different -- it's the variational contribution
			else {
				//				std::cout << "FOUND: " << conditionals[neigh] << std::endl;
				posprob += jacobian_conditionals[neigh]*log(y_cond.getNormalized(1, 1)) + (1-jacobian_conditionals[neigh])*log(y_cond.getNormalized(1, 0));
				negprob += jacobian_conditionals[neigh]*log(y_cond.getNormalized(0, 1)) + (1-jacobian_conditionals[neigh])*log(y_cond.getNormalized(0, 0));
			}
		}

		// These are our exponential components
		double exp_pos = exp(posprob);
		double exp_neg = exp(negprob);
		double partition = exp_pos + exp_neg;

		if (posprob < minlogprob_pos or negprob < minlogprob_neg)
		{
			minlogprob_pos = posprob;
			minlogprob_neg = negprob;
		}
		// Occassionally the values are very, very small
		if (partition*partition == 0)
		{
			double mval = posprob;
			if (negprob > posprob) mval = negprob;

			posprob -= mval;
			negprob -= mval;

			exp_pos = exp(posprob);
			exp_neg = exp(negprob);
			partition = exp_pos + exp_neg;
		}

		// These are the four possible partial derivatives for RNB.  They do not depend on the actual value of the unlabeled neighbor
		double pos_i_pos_j_partial = (log(y_cond.getNormalized(1,1))*exp_pos*partition - exp_pos*(log(y_cond.getNormalized(1,1))*exp_pos + log(y_cond.getNormalized(0, 1))*exp_neg)) / (partition * partition);
		double pos_i_neg_j_partial = (log(y_cond.getNormalized(1,0))*exp_pos*partition - exp_pos*(log(y_cond.getNormalized(1,0))*exp_pos + log(y_cond.getNormalized(0, 0))*exp_neg)) / (partition * partition);
		double neg_i_pos_j_partial = (log(y_cond.getNormalized(0,1))*exp_neg*partition - exp_neg*(log(y_cond.getNormalized(1,1))*exp_pos + log(y_cond.getNormalized(0, 1))*exp_neg)) / (partition * partition);
		double neg_i_neg_j_partial = (log(y_cond.getNormalized(0,0))*exp_neg*partition - exp_neg*(log(y_cond.getNormalized(1,0))*exp_pos + log(y_cond.getNormalized(0, 0))*exp_neg)) / (partition * partition);

		/*	Matrix structure
		 * 		v_j
		v_i		P-P | P-N
				N-P | N-N
		 */
		// Assign for each unlabeled neighbor
		int v_jacobian_id_pos = unlabeled_j_ids[v];
		int v_jacobian_id_neg = unlabeled_j_ids[v]+into_jacobian.size();
		int n_count = 0;
		for (int neigh : neighbors(v)) {
			// Only need the unlabeled neighbors
			if (into_jacobian.find(neigh) != into_jacobian.end()) {
				int n_jacobian_id_pos = unlabeled_j_ids[neigh];
				int n_jacobian_id_neg = unlabeled_j_ids[neigh]+into_jacobian.size();
				tripletList.push_back(T(v_jacobian_id_pos, n_jacobian_id_pos, pos_i_pos_j_partial));
				tripletList.push_back(T(v_jacobian_id_pos, n_jacobian_id_neg, pos_i_neg_j_partial));
				tripletList.push_back(T(v_jacobian_id_neg, n_jacobian_id_pos, neg_i_pos_j_partial));
				tripletList.push_back(T(v_jacobian_id_neg, n_jacobian_id_neg, neg_i_neg_j_partial));
				n_count++;
			}
		}
	}

	jacobian.setFromTriplets(tripletList.begin(), tripletList.end());

	double maxval = Helpers::PowerMethod(jacobian);

	return maxval;
}




double RNB::computeConditional(int v)
{
	//	Initial probs
	double posprob = log(posprior);
	double negprob = log(1-posprior);

	// Include attributes
	for(int i=0; i < x_conds.size(); i++) {
		posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
		negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
	}

	// Include edges
	for (int neigh : lab_neighbors(v)) {
		posprob += log(y_cond.getNormalized(1, ys[neigh]));
		negprob += log(y_cond.getNormalized(0, ys[neigh]));
	}

	double prob = exp(posprob) / (exp(posprob) + exp(negprob));
	return prob;
}




/*
 * helper function to normalize our conditional distributions
 */
void RNB::normalizeConds()
{
	y_cond.normalize();
	NB::normalizeConds();
}


void RNB::learnModel()
{
	YS::iterator y;
	int samples = 0;

	// Initialize Priors
	setPriors();

	double pos,tot;
	pos = .5;
	tot = 1;

	int v, neigh;

	int ylabel;


	double tmp_pos_prior  = pos/tot;

	pos = .5;
	tot = 1;
	// For every labeled instance, learn the RNB model
	for(int v : _labeled_vertices) {
		ylabel = ys[v];

		// Update Attributes
		for(int i=0; i < x_conds.size(); i++)
		{
			x_conds[i].increment(ylabel, xs[v][i]);
		}

		// Update relational
		for (int neigh : lab_neighbors(v)) {
			y_cond.increment(ylabel, ys[neigh]);
		}

		// Update the prior
		if(ylabel == 1) pos++;
		tot++;
	}

	// Normalize it all
	posprior = pos/tot;

	normalizeConds();
}



void RNB::computeConditionals()
{
	YS::iterator y;

	int v, neigh;

	// Remove whatever might already be there
	conditionals.clear();

	double average = 0;
	// For all the unlabeled cases
	for (int v : _unlabeled_vertices)
	{
		// Initial probs
		double posprob = log(posprior);
		double negprob = log(1-posprior);

		// Include attributes
		for(int i=0; i < x_conds.size(); i++) {
			posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
			negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
		}

		// Include edges
		for (int neigh : lab_neighbors(v)) {
			posprob += log(y_cond.getNormalized(1, ys[neigh]));
			negprob += log(y_cond.getNormalized(0, ys[neigh]));
		}

		double prob = exp(posprob) / (exp(posprob) + exp(negprob));
		conditionals[v] = prob;
		average += prob;
	}
	average /= _unlabeled_vertices.size();

	_within_iteration_eigenvalues.clear();
	this->SetJacobianConditionals(conditionals);
	double j = this->computeVariationalJacobianMaxEigenvalue();
	_within_iteration_eigenvalues.push_back(j);
	_within_iteration_eigenvalues.push_back(j);

	_cross_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.push_back(j);
	_cross_iteration_eigenvalues.push_back(j);

	this->SetJacobianConditionals(true_conditionals);
	j = this->computeVariationalJacobianMaxEigenvalue();
	_perfect_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.push_back(j);
	_perfect_iteration_eigenvalues.push_back(j);
	_converged_values.clear();
	_converged_values.push_back(average);
	_converged_values.push_back(average);


}



void RNB::computeLabeledConditionals()
{
	YS::iterator y;

	int v, neigh;

	// Remove whatever might already be there
	conditionals.clear();


	// For all the border cases
	for(int v: _labeled_vertices)
	{
		// Initial probs
		double posprob = log(posprior);
		double negprob = log(1-posprior);

		// Include attributes
		for(int i=0; i < x_conds.size(); i++) {
			posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
			negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
		}

		// Include edges
		for (int neigh : lab_neighbors(v)) {
			posprob += log(y_cond.getNormalized(1, ys[neigh]));
			negprob += log(y_cond.getNormalized(0, ys[neigh]));
		}

		double prob = exp(posprob) / (exp(posprob) + exp(negprob));
		conditionals[v] = prob;
	}

//	for (int i = 0; i < 50; i++) {
//		std::vector<int> estimating(_labeled_vertices.begin(), _labeled_vertices.end());
//		std::random_shuffle(estimating.begin(), estimating.end());
//
//		// For all the border cases
//		for(int v: estimating)
//		{
//			// Initial probs
//			double posprob = log(posprior);
//			double negprob = log(1-posprior);
//
//			// Include attributes
//			for(int i=0; i < x_conds.size(); i++) {
//				posprob += log(x_conds[i].getNormalized(1, xs[v][i]));
//				negprob += log(x_conds[i].getNormalized(0, xs[v][i]));
//			}
//
//			// Include edges
//			for (int neigh : lab_neighbors(v)) {
//				posprob += conditionals[v]*log(y_cond.getNormalized(1, 1)) + (1-conditionals[v])*log(y_cond.getNormalized(1, 0));
//				negprob += conditionals[v]*log(y_cond.getNormalized(0, 1)) + (1-conditionals[v])*log(y_cond.getNormalized(0, 0));
//			}
//
//			double prob = exp(posprob) / (exp(posprob) + exp(negprob));
//			conditionals[v] = prob;
//		}
//	}
}


#endif /* RNB_HPP_ */
