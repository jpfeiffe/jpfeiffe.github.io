/*
 * RNB.hpp
 *
 *  Created on: Oct 18, 2012
 */

#ifndef RNB_EM_HPP_
#define RNB_EM_HPP_

#include "RNB.hpp"
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include "eigen3/Eigen/Sparse"
#include "eigen3/Eigen/UmfPackSupport"

class RNB_EM : public RNB {
public:
	enum REPRESENTATION {R_EM, R_SEM, R_SEM_VMF, R_DA};
	enum LEARNING_UPDATE {MF_APPROX, GIBBS};

protected:
	std::map<int, double > last_conditionals;
	std::unordered_map<int, std::vector<int>> last_samples;
	int _em_iterate, _bp_iterate, _sem_final;
	LEARNING_UPDATE _learning_update;
	REPRESENTATION _representation;

	double avg_expected_value;
	bool _last_init;
public:
	RNB_EM(eigen_matrix ugraph = eigen_matrix(), int num_attr=2, int num_em_iterations=5, int num_bp_iterations=3, REPRESENTATION rep=R_EM, LEARNING_UPDATE lupdate = MF_APPROX)
: RNB(ugraph, num_attr)	{
		_method_name = "EM";
		_em_iterate = num_em_iterations;
		_bp_iterate = num_bp_iterations;
		_sem_final = 100;
		_representation = rep;
		_learning_update = lupdate;
		_last_init = false;
		avg_expected_value = 0;
	}

	void setLastInit(bool v) {_last_init = v;}
	virtual Classifier* Clone();
	void setEMIterations(int num_iter) {_em_iterate = num_iter;}
	void setBPIterations(int num_iter) {_bp_iterate = num_iter;}
	void setSEMFinal(int num_iter) {_sem_final = num_iter;}
	void learnModel();
	void EStep(int em_iteration, int bp_iterations, std::vector<double>& expected_values, std::vector<int>& gibbs_samples,
			std::vector<double>& border_feature_pos, std::vector<double>& border_feature_neg,
			std::vector<double>& bp_iteration_expectation_summation, std::vector<double>& bp_iteration_gibbs_summation, std::vector<double>& all_em_iteration_expectation_summation, std::vector<double>& all_em_iteration_gibbs_summation);

	void MStep(std::vector<double> expected_values);
	void SetupTester(XS);

	// These are the same in this case
	void computeConditionals();
};


Classifier* RNB_EM::Clone()
{
	RNB_EM *newrnb = new RNB_EM(graph, _num_attr,  _em_iterate, _bp_iterate, _representation, _learning_update);
	return newrnb;
}

void RNB_EM::SetupTester(XS new_xs)
{
	RNB::SetupTester(new_xs);
	setPriors();
}

/*
 * Basic Relational Naive Bayes learner
 */
void RNB_EM::learnModel()
{
	// SEM Aggregates
	Binary agg_y_cond;
	double agg_posprior;
	double _pp_old(0), _pp_new(0);
	double _pn_old(0), _pn_new(0);
	double _np_old(0), _np_new(0);
	double _nn_old(0), _nn_new(0);

	// For recording results
	_w00.clear(); _w01.clear(); _w10.clear(); _w11.clear();

	// With RNB no reason to continually recompute the features
	std::vector<double> border_feature_pos; border_feature_pos.resize(num_vertices(), 0);
	std::vector<double> border_feature_neg; border_feature_neg.resize(num_vertices(), 0);

	// Used for EM or Gibbs Sampling
	std::vector<double> expected_values; expected_values.resize(num_vertices(), 0);
	std::vector<int> gibbs_samples; gibbs_samples.resize(num_vertices(), 0);

	// Some summations we will keep track of
	std::vector<double> bp_iteration_expectation_summation; bp_iteration_expectation_summation.resize(num_vertices(), 0);
	std::vector<double> bp_iteration_gibbs_summation; bp_iteration_gibbs_summation.resize(num_vertices(), 0);
	std::vector<double> all_em_iteration_expectation_summation; all_em_iteration_expectation_summation.resize(num_vertices(), 0);
	std::vector<double> all_em_iteration_gibbs_summation; all_em_iteration_gibbs_summation.resize(num_vertices(), 0);

	last_samples.clear();

	// Start out by learning with RNB
	RNB::learnModel();

	_within_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.clear();
	_converged_values.clear();

	// Store the attr conditionals so we don't have to recompute
	for (const int& v : _unlabeled_vertices)
	{
		double posfeat = 0;
		double negfeat = 0;

		// Include attributes
		for(int i=0; i < x_conds.size(); i++) {
			posfeat += log(x_conds[i].getNormalized(1, xs[v][i]));
			negfeat += log(x_conds[i].getNormalized(0, xs[v][i]));
		}

		// Store these off (never change for NB)
		border_feature_pos[v] = posfeat;
		border_feature_neg[v] = negfeat;
	}

	double j;
	bool true_last_init = _last_init;
	if (_representation == R_SEM or _representation == R_SEM_VMF or _representation == R_DA) {
		_last_init = true;
	}
	// Do EM
	for (int em_iteration = 0; em_iteration < _em_iterate; em_iteration++) {
		EStep(em_iteration, _bp_iterate, expected_values, gibbs_samples, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);


		// How are we going to represent the update?
		switch (_representation) {
		case R_EM:
			// If we're using R-EM & Gibbs need to compute the E-step
			if (_learning_update == GIBBS) {
				for (const int& v : _unlabeled_vertices) {
					expected_values[v] = bp_iteration_gibbs_summation[v] / _bp_iterate;
				}
			}
			break;
		case R_SEM:
		case R_SEM_VMF:
			// Intentional Fallthrough
		case R_DA:
			for (const int& v : _unlabeled_vertices)
				expected_values[v] = gibbs_samples[v];
			break;
		}

		if (_representation == R_EM and em_iteration >= _em_iterate-2) {
			SetJacobianConditionals(expected_values);
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_within_iteration_eigenvalues.push_back(j);
		}
		if (_representation == R_EM and _em_iterate==1) {
			SetJacobianConditionals(expected_values);
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_within_iteration_eigenvalues.push_back(j);
		}


		// Maximize it all now
		// We use the approximation
		MStep(expected_values);

		if (_representation == R_EM and em_iteration >= _em_iterate-2) {
			SetJacobianConditionals(expected_values);
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_cross_iteration_eigenvalues.push_back(j);
			SetJacobianConditionals(GetTrueConditionals());
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_perfect_iteration_eigenvalues.push_back(j);
			_converged_values.push_back(avg_expected_value);
		}
		if (_representation == R_EM and _em_iterate == 1) {
			SetJacobianConditionals(expected_values);
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_cross_iteration_eigenvalues.push_back(j);
			SetJacobianConditionals(GetTrueConditionals());
			j = RNB::computeVariationalJacobianMaxEigenvalue();
			_perfect_iteration_eigenvalues.push_back(j);
			_converged_values.push_back(avg_expected_value);
		}

		_w00.push_back(y_cond.getNormalized(0,0));
		_w01.push_back(y_cond.getNormalized(0,1));
		_w10.push_back(y_cond.getNormalized(1,0));
		_w11.push_back(y_cond.getNormalized(1,1));

		// Running total of parameters
		agg_y_cond.AddBinaryNormalized(y_cond);
		agg_posprior += posprior;


		if (em_iteration == _em_iterate-2) {
			_pp_old = y_cond.getNormalized(1,1);
			_pn_old = y_cond.getNormalized(1,0);
			_np_old = y_cond.getNormalized(0,1);
			_nn_old = y_cond.getNormalized(0,0);
		}
		else if (em_iteration == _em_iterate-1) {
			_pp_new = y_cond.getNormalized(1,1);
			_pn_new = y_cond.getNormalized(1,0);
			_np_new = y_cond.getNormalized(0,1);
			_nn_new = y_cond.getNormalized(0,0);
		}
	}


	// MAP parameters
	agg_posprior /= _em_iterate;
	posprior = agg_posprior;
	y_cond.setBinary(agg_y_cond);
	y_cond.normalize();


	_last_init = true_last_init;
	double pos_total, tot_total;
	// How are we going to represent the finalized version?
	switch (_representation) {
	case R_DA:
		avg_expected_value = 0;
		for (const int& v : _unlabeled_vertices) {
			expected_values[v] = all_em_iteration_gibbs_summation[v] / (_bp_iterate * (_em_iterate));
			avg_expected_value += expected_values[v];
		}
		avg_expected_value /= _unlabeled_vertices.size();
		break;

	case R_SEM:
		// Gibbs additional sampling
		EStep(_em_iterate+1, _sem_final, expected_values, gibbs_samples, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);
		avg_expected_value = 0;
		for (const int& v : _unlabeled_vertices) {
			expected_values[v] = bp_iteration_gibbs_summation[v] / (_sem_final);
			avg_expected_value += expected_values[v];
		}
		avg_expected_value /= _unlabeled_vertices.size();
		break;

	case R_SEM_VMF:
		// MF additional trial
		_learning_update = MF_APPROX;
		EStep(_em_iterate+1, _sem_final, expected_values, gibbs_samples, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);
		_learning_update = GIBBS;
		break;

	}

	if (_representation == R_SEM or _representation == R_SEM_VMF or _representation == R_DA)
	{
		_converged_values.push_back(avg_expected_value);
		_converged_values.push_back(avg_expected_value);
		SetJacobianConditionals(expected_values);
		j = RNB::computeVariationalJacobianMaxEigenvalue();
		_within_iteration_eigenvalues.push_back(j);
		_within_iteration_eigenvalues.push_back(j);
		SetJacobianConditionals(GetTrueConditionals());
		j = RNB::computeVariationalJacobianMaxEigenvalue();
		_perfect_iteration_eigenvalues.push_back(j);
		MStep(expected_values);
		SetJacobianConditionals(expected_values);
		j = RNB::computeVariationalJacobianMaxEigenvalue();
		_cross_iteration_eigenvalues.push_back(j);
		_cross_iteration_eigenvalues.push_back(j);
		SetJacobianConditionals(GetTrueConditionals());
		j = RNB::computeVariationalJacobianMaxEigenvalue();
		_perfect_iteration_eigenvalues.push_back(j);

	}


	last_conditionals.clear();
	for (const int& v : _unlabeled_vertices)	{
		last_conditionals[v] = expected_values[v];
	}

	_param_variance = (_pp_old - _pp_new)*(_pp_old - _pp_new);
	_param_variance += (_pn_old - _pn_new)*(_pn_old - _pn_new);
	_param_variance += (_np_old - _np_new)*(_np_old - _np_new);
	_param_variance += (_nn_old - _nn_new)*(_nn_old - _nn_new);
}


void RNB_EM::EStep(int em_iteration, int bp_iterations, std::vector<double>& expected_values, std::vector<int>& gibbs_samples,
		std::vector<double>& border_feature_pos, std::vector<double>& border_feature_neg,
		std::vector<double>& bp_iteration_expectation_summation, std::vector<double>& bp_iteration_gibbs_summation, std::vector<double>& all_em_iteration_expectation_summation, std::vector<double>& all_em_iteration_gibbs_summation)
{
	std::vector<int> estimating_vertices(_unlabeled_vertices.begin(), _unlabeled_vertices.end());

	_total_positives.clear();
	_total_negatives.clear();

	// Loop over all the iterations
	for (int bp_iteration = 0; bp_iteration < bp_iterations; bp_iteration++) {
		avg_expected_value = 0;
		double count = 0;
		double diff = 0;
		double num_positives = 0;
		std::random_shuffle(estimating_vertices.begin(), estimating_vertices.end());
		for (const int& v : estimating_vertices) {
			count++;
			// Initial probs
			double posprob = log(posprior) + border_feature_pos[v];
			double negprob = log(1-posprior) + border_feature_neg[v];

			// Include edges
			std::vector<int> v_neighbors = neighbors((int)v);
			for (const int& neigh : v_neighbors) {
				if(_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
					posprob += log(y_cond.getNormalized(1, ys[neigh]));
					negprob += log(y_cond.getNormalized(0, ys[neigh]));
				}

				else if (_learning_update == MF_APPROX and (bp_iteration > 0 or (em_iteration > 0 and _last_init))) {
					posprob += (expected_values[neigh]*log(y_cond.getNormalized(1, 1)) + (1-expected_values[neigh])*log(y_cond.getNormalized(1, 0)));
					negprob += (expected_values[neigh]*log(y_cond.getNormalized(0, 1)) + (1-expected_values[neigh])*log(y_cond.getNormalized(0, 0)));
				}

				else if (_learning_update == GIBBS and (bp_iteration > 0 or (em_iteration > 0 and _last_init))) {
					posprob += log(y_cond.getNormalized(1, gibbs_samples[neigh]));
					negprob += log(y_cond.getNormalized(0, gibbs_samples[neigh]));
				}
			}

			// Update the expectations and draw a gibbs sample
			double old_e = expected_values[v];

			expected_values[v] = exp(posprob) / (exp(posprob) + exp(negprob));

			// MF can get really extreme values -- correcting for this
			if (isnan(expected_values[v]))
			{
				double mval = posprob;
				if (negprob > posprob) mval = negprob;

				posprob -= mval;
				negprob -= mval;

				expected_values[v] = exp(posprob) / (exp(posprob) + exp(negprob));
			}

			diff = abs(old_e) - expected_values[v];
			avg_expected_value += expected_values[v];
			gibbs_samples[v] = ((double)rand())/RAND_MAX < expected_values[v];
			last_samples[v].push_back(gibbs_samples[v]);
			if (gibbs_samples[v] == 1)
				num_positives++;

			// Reset the various iterations if necessary
			if (bp_iteration == 0) {
				bp_iteration_expectation_summation[v] = 0;
				bp_iteration_gibbs_summation[v] = 0;
				if (em_iteration == 0) {
					all_em_iteration_expectation_summation[v] = 0;
					all_em_iteration_gibbs_summation[v] = 0;
				}
			}
			// Update the sums
			bp_iteration_expectation_summation[v] += expected_values[v];
			all_em_iteration_expectation_summation[v] += expected_values[v];
			bp_iteration_gibbs_summation[v] += gibbs_samples[v];
			all_em_iteration_gibbs_summation[v] += gibbs_samples[v];
		}

		avg_expected_value /= estimating_vertices.size();
		diff /= estimating_vertices.size();
		_total_positives.push_back(num_positives);
		_total_negatives.push_back(estimating_vertices.size() - num_positives);
	}
}


void RNB_EM::MStep(std::vector<double> expected_values)
{
	double pos_total = .5;
	double tot_total = 1;

	y_cond.setAll(prior_weight);
	for (const int& v : _labeled_vertices) {
		// Update relational
		for (const int& neigh : neighbors(v)) {
			if(_labeled_vertices.find(neigh) != _labeled_vertices.end()) y_cond.increment(ys[v], ys[neigh]);
			else  {
				y_cond.increment(ys[v], 1, (expected_values[neigh]));
				y_cond.increment(ys[v], 0, (1-expected_values[neigh]));
			}
		}

		// Update the prior
		if(ys[v] == 1) pos_total++;
		tot_total++;
	}
	posprior = pos_total/tot_total;
	y_cond.normalize();
}

void RNB_EM::computeConditionals()
{
	conditionals.clear();
	for(std::map<int,double>::iterator it = last_conditionals.begin(); it!=last_conditionals.end(); it++)
	{
		conditionals[it->first] = it->second;
	}
}


#endif /* RNB_EM_HPP_ */
