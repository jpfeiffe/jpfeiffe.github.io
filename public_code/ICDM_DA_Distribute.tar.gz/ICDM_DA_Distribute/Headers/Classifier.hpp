

#ifndef CLASSIFIER_HPP_
#define CLASSIFIER_HPP_

#include <unordered_set>
#include <map>
#include <vector>
#include "LabeledGraph.hpp"

class Classifier : public LabeledGraph{
protected:
	std::map<int, double > conditionals;
	std::map<int, double > true_conditionals;
	std::map<int, double > jacobian_conditionals;

	std::unordered_set<int> _unlabeled_vertices;
	std::unordered_set<int> _labeled_vertices;

	std::vector<int> _total_positives;
	std::vector<int> _total_negatives;

	std::vector<double> _w00;
	std::vector<double> _w01;
	std::vector<double> _w10;
	std::vector<double> _w11;

	std::vector<double> _within_iteration_eigenvalues;
	std::vector<double> _cross_iteration_eigenvalues;
	std::vector<double> _perfect_iteration_eigenvalues;
	std::vector<double> _converged_values;


	double _param_variance;
public:
	Classifier(eigen_matrix new_graph = eigen_matrix(), int num_attr = 2)
: LabeledGraph(new_graph, num_attr)
{
		_method_name = "Classifier";
		_unlabeled_vertices = std::unordered_set<int>();
		_labeled_vertices = std::unordered_set<int>();
		conditionals = std::map<int,double>();
		true_conditionals = std::map<int,double>();
		_param_variance = 0;
}
	~Classifier() {  }

	virtual Classifier* Clone() = 0;

	/*
	 * Properties relating to graph structure of Active Exploration that applies to all methods
	 */
	// Get particular subsets of nodes
	std::vector<int> getLabeledInstances(){return std::vector<int>(_labeled_vertices.begin(), _labeled_vertices.end());}
	std::unordered_set<int> getLabeledInstancesSet(){return std::unordered_set<int>(_labeled_vertices.begin(), _labeled_vertices.end());}
	std::vector<int> getUnlabeledInstances(){return std::vector<int>(_unlabeled_vertices.begin(), _unlabeled_vertices.end());}
	void setLabeledInstances(std::vector<int> new_vertices){
		_labeled_vertices = std::unordered_set<int>(new_vertices.begin(), new_vertices.end());
		for (int v : _labeled_vertices) _unlabeled_vertices.erase(v);
	}
	void setUnlabeledInstances(std::vector<int> new_vertices){
		_unlabeled_vertices = std::unordered_set<int>(new_vertices.begin(), new_vertices.end());
		for (int v : _unlabeled_vertices) _labeled_vertices.erase(v);
	}
	void setUnlabeledInstances(std::unordered_set<int> new_vertices){
		_unlabeled_vertices = std::unordered_set<int>(new_vertices.begin(), new_vertices.end());
		for (int v : _unlabeled_vertices) _labeled_vertices.erase(v);
	}
	void clearUnlabeledInstances(std::vector<int> new_vertices){
		for(int v : new_vertices) ys[v] = -1;
		_unlabeled_vertices = std::unordered_set<int>(new_vertices.begin(), new_vertices.end());
	}

	YS retrieveLabelings(std::vector<int> vertices);

	double getParameterVariance() {return _param_variance;}
	std::vector<int> getTotalPositives() {return _total_positives;}
	std::vector<int> getTotalNegatives() {return _total_negatives;}
	std::vector<double> getW00() {return _w00;}
	std::vector<double> getW01() {return _w01;}
	std::vector<double> getW10() {return _w10;}
	std::vector<double> getW11() {return _w11;}

	/*
	 * Learning and drawing from the estimators
	 */
	// Different ways to learn our estimators
	virtual void learnModel() = 0;

	// Compute and fetch our conditionals in various ways
	virtual double computeConditional(int v) = 0;
	virtual void computeConditionals() = 0;
	virtual void computeLabeledConditionals() = 0;
	virtual double getConditional(int v) {if (conditionals.find(v) != conditionals.end()) return conditionals[v];  return -1;}

	virtual void SetConditionals(std::map<int, double > new_conditionals)
	{
		conditionals.clear();
		conditionals.insert(new_conditionals.begin(), new_conditionals.end());
	}
	virtual void SetTrueConditionals(std::map<int, double > new_conditionals)
	{
		true_conditionals.clear();
		true_conditionals.insert(new_conditionals.begin(), new_conditionals.end());
	}
	virtual std::map<int, double > GetTrueConditionals()
	{
		std::map<int, double > newconds;
		newconds.insert(true_conditionals.begin(), true_conditionals.end());
		return newconds;
	}
	virtual std::map<int,double> GetConditionals()
	{
		return std::map<int,double>(conditionals.begin(), conditionals.end());
	}

	void SetJacobianConditionals(std::vector<double> vals)
	{
		jacobian_conditionals.clear();
		for (const int& v : _unlabeled_vertices) {
			jacobian_conditionals[v] = vals[v];
		}
	}

	void SetJacobianConditionals(std::map<int,double> vals)
	{
		jacobian_conditionals.clear();
		jacobian_conditionals.insert(vals.begin(), vals.end());
	}

	/*
	 * Setting features in the network.  Need to keep track of border/unlabeled/labeled items
	 */
	virtual void setY(int v, int label);
	virtual void setYS(YS newys);
	virtual void insertYS(YS newys);
	virtual void SetupTester(XS xs){LabeledGraph::SetupTester(xs); _labeled_vertices.clear(); _unlabeled_vertices.clear();}
	virtual void SetupEmptyTester(int count, int num_features){LabeledGraph::SetupEmptyTester(count,num_features); _labeled_vertices.clear(); _unlabeled_vertices.clear();}

	// Some Statistics we need
	virtual double Compute01Loss(std::map<int,double> estimates);
	virtual double ComputeMAE(std::map<int,double> estimates);
	virtual double ComputeBAE(std::map<int,double> estimates);

	virtual double computeWithinIterationJacobianMaxEigenvalue(int ind) {return _within_iteration_eigenvalues[ind];}
	virtual double computeCrossIterationJacobianMaxEigenvalue(int ind) {return _cross_iteration_eigenvalues[ind];}
	virtual double computePerfectIterationJacobianMaxEigenvalue(int ind) {return _perfect_iteration_eigenvalues[ind];}
	virtual double computeConvergedValues(int ind) {return _converged_values[ind];}
	virtual double computeParameterVariance() {return 0;}
	void ReadFile(std::string filename);

	std::vector<int> lab_neighbors(int v);
	std::vector<int> unlab_neighbors(int v);
};


void Classifier::ReadFile(std::string filename)
{
	LabeledGraph::ReadFile(filename);
	for (std::pair<int, Y> y : ys)
		if (y.second >= 0) _labeled_vertices.insert(y.first);
}


void Classifier::setY(int v, int label)
{
	LabeledGraph::setY(v, label);
	_labeled_vertices.insert(v);
	if (_unlabeled_vertices.find(v) != _unlabeled_vertices.end())
		_unlabeled_vertices.erase(v);
}


void Classifier::setYS(YS newys)
{
	_labeled_vertices.clear();
	_unlabeled_vertices.clear();

	LabeledGraph::setYS(newys);

	for (std::pair<int, Y> newy : newys) {
		int v = newy.first;
		int label = newy.second;
		if (label != -1) {
			_labeled_vertices.insert(v);
		}
		else
			_unlabeled_vertices.insert(v);
	}
}


void Classifier::insertYS(YS newys)
{
	for (std::pair<int, Y> newy : newys) {
		setY(newy.first, newy.second);
	}
}


YS Classifier::retrieveLabelings(std::vector<int> vertices)
{
	std::vector<int>::iterator vi;
	YS labelings;

	for(vi = vertices.begin(); vi != vertices.end(); vi++) {
		labelings[*vi] = ys[*vi];
	}

	return labelings;
}


double Classifier::ComputeMAE(std::map<int,double> estimates)
{
	std::vector<std::pair<double, int> > pairs;

	for (std::pair<int, double> e : estimates) {
		int yval = ys[e.first];
		if (yval >= 0) {
			pairs.push_back(std::pair<double,int>(e.second, yval));
		}
	}

	return Helpers::ComputeMAE(pairs);
}


double Classifier::ComputeBAE(std::map<int,double> estimates)
{
	std::vector<std::pair<double, int> > pairs;

	for (std::pair<int, double> e : estimates) {
		int yval = ys[e.first];
		if (yval >= 0) {
			pairs.push_back(std::pair<double,int>(e.second, yval));
		}
	}

	return Helpers::ComputeBAE(pairs);
}




double Classifier::Compute01Loss(std::map<int,double> estimates)
{
	double auc = 0;

	std::vector<std::pair<double, int> > pairs_for_auc;

	for (std::map<int,double>::iterator e_it = estimates.begin(); e_it != estimates.end(); e_it++) {
		int yval = ys[e_it->first];
		if (yval >= 0) {
			pairs_for_auc.push_back(std::pair<double,int>(e_it->second, yval));
		}
	}

	return Helpers::Compute01Loss(pairs_for_auc);
}


std::vector<int> Classifier::lab_neighbors(int v)
{
	std::vector<int> n;
	for (int neigh : neighbors(v)) {
		if (_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
			n.push_back(neigh);
		}
	}
	return n;
}

std::vector<int> Classifier::unlab_neighbors(int v)
{
	std::vector<int> n;
	for (int neigh : neighbors(v)) {
		if (_labeled_vertices.find(neigh) == _labeled_vertices.end()) {
			n.push_back(neigh);
		}
	}
	return n;
}


#endif /* ACTIVESAMPLER_HPP_ */
