

#ifndef HELPERS_HPP_
#define HELPERS_HPP_

#include <set>

#include "Classifier.hpp"

namespace Helpers {
bool SortPairs( const std::pair<double, int>& i, const std::pair<double, int>& j ) {
	return i.first < j.first;
}

bool SortPairsRev( const std::pair<double, int>& i, const std::pair<double, int>& j ) {
	return i.first > j.first;
}


double Compute01Loss(std::vector<std::pair<double,int> > probs, double threshold=.5) {
	int num_right = 0;
	int num_wrong = 0;
	for (std::pair<double, int> prob : probs) {
		if ((prob.first > threshold && prob.second == 1) || (prob.first < threshold && prob.second == 0))
			num_right++;
		else
			num_wrong++;
	}

	return (double)num_wrong / (num_right + num_wrong);
}

double ComputeMAE(std::vector<std::pair<double,int> > probs) {
	double total_err = 0;

	int count = probs.size();

	double neg_err = 0;
	double pos_err = 0;
	double poss = 0;
	double negs = 0;
	double mean_val = 0;
	for (std::pair<double,int> p : probs) {
		mean_val += p.first;
		if (p.second == 0) {total_err += p.first; neg_err += p.first; negs++;}
		else if (p.second == 1)	{total_err += (1 - p.first); pos_err += (1 - p.first); poss++;}
		else count--;
	}

	return total_err / count;
}



double ComputeBAE(std::vector<std::pair<double,int> > probs) {
	double total_err = 0;

	int count = probs.size();

	double neg_err = 0;
	double pos_err = 0;
	double poss = 0;
	double negs = 0;
	double mean_val = 0;
	for (std::pair<double,int> p : probs) {
		mean_val += p.first;
		if (p.second == 0) {total_err += p.first; neg_err += p.first; negs++;}
		else if (p.second == 1)	{total_err += (1 - p.first); pos_err += (1 - p.first); poss++;}
		else count--;
	}

	pos_err /= poss;
	neg_err /= negs;

	return (pos_err + neg_err) / 2;
}

double PearsonCorrelation(std::vector<double> var1, std::vector<double> var2)
{
	double m1, m2, s1, s2, s12;
	m1 = m2 = s1 = s2 = s12 = 0;

	// Compute means
	for(int i = 0; i < var1.size(); i++) {
		m1 += var1[i];
		m2 += var2[i];
	}

	m1 /= var1.size();
	m2 /= var2.size();

	// Compute var/std stats
	for (int i = 0; i < var1.size(); i++) {
		s1 += (var1[i] - m1)*(var1[i] - m1);
		s2 += (var2[i] - m2)*(var2[i] - m2);
		s12 += (var1[i] - m1)*(var2[i] - m2);
	}

	return s12 / (sqrt(s1)*sqrt(s2));
}


double PowerMethod(eigen_matrix mat, int iterations=1000)
{
	int cols = mat.cols();
	eigen_vector b = eigen_vector::Random(cols);
	eigen_vector b2;

	double lambda = b.norm();
	b.normalize();

	double sq = 10;
	double diff = 10;
	for (int i = 0; i < iterations; i++)
	{
		double old_lambda = lambda;
		b2 = mat * b;

		lambda = b2.norm();
		diff = fabs(old_lambda - lambda);
		b2.normalize();

		eigen_vector b3 = b - b2;
		sq = b3.transpose() * b3;
		b = b2;
	}

	return lambda;
}



void WriteoutResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, std::vector<double> percentages, std::vector<std::vector<std::vector<double> > > method_res)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < percentages.size(); s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << percentages[s];
		file_stderr << percentages[s];
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean, var;
		mean = var = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean = var = 0;
			for (int t = 0; t < trials; t++) {
				mean += method_res[m][t][s];
			}
			mean /= trials;
			for (int t = 0; t < trials; t++) {
				var += (method_res[m][t][s] - mean)*(method_res[m][t][s] - mean);
			}

			if (trials == 1)
				var = 0;
			else {
				var /= (trials - 1);
				var = sqrt(var);
			}

			file_mean << "\t" << mean;
			file_stderr << "\t" << var / sqrt(trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}



void WriteoutResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, int iterations, std::vector<std::vector<std::vector<int> > > method_res)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < iterations; s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << s;
		file_stderr << s;
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean, var;
		mean = var = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean = var = 0;
			for (int t = 0; t < trials; t++) {
				mean += method_res[m][t][s];
			}
			mean /= trials;
			for (int t = 0; t < trials; t++) {
				var += (method_res[m][t][s] - mean)*(method_res[m][t][s] - mean);
			}

			if (trials == 1)
				var = 0;
			else {
				var /= (trials - 1);
				var = sqrt(var);
			}

			file_mean << "\t" << mean;
			file_stderr << "\t" << var / sqrt(trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}



void WriteoutResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, int iterations, std::vector<std::vector<std::vector<double> > > method_res)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < iterations; s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << s;
		file_stderr << s;
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean, var;
		mean = var = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean = var = 0;
			for (int t = 0; t < trials; t++) {
				mean += method_res[m][t][s];
			}
			mean /= trials;
			for (int t = 0; t < trials; t++) {
				var += (method_res[m][t][s] - mean)*(method_res[m][t][s] - mean);
			}

			if (trials == 1)
				var = 0;
			else {
				var /= (trials - 1);
				var = sqrt(var);
			}

			file_mean << "\t" << mean;
			file_stderr << "\t" << var / sqrt(trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}


void WriteoutResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, std::vector<double> percentages, std::vector<std::vector<std::vector<double> > > iteration1, std::vector<std::vector<std::vector<double> > > iteration2)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < percentages.size(); s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << percentages[s];
		file_stderr << percentages[s];
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean1, var1, mean2, var2;
		mean1 = var1 = mean2 = var2 = 0;

		for (int m = 0; m < methods.size(); m++) {
			int true_trials = trials;
			mean1 = var1 = mean2 = var2 = 0;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					true_trials--;
					continue;
				}
				mean1 += iteration1[m][t][s];
				mean2 += iteration2[m][t][s];
			}
			mean1 /= true_trials;
			mean2 /= true_trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					continue;
				}
				var1 += (iteration1[m][t][s] - mean1)*(iteration1[m][t][s] - mean1);
				var2 += (iteration2[m][t][s] - mean2)*(iteration2[m][t][s] - mean2);
			}

			if (true_trials <= 1) {
				var1 = 0;
				var2 = 0;
			}
			else {
				var1 /= (true_trials - 1);
				var1 = sqrt(var1);
				var2 /= (true_trials - 1);
				var2 = sqrt(var2);
			}

			file_mean << "\t" << mean1 << ":" << mean2;
			file_stderr << "\t" << var1 / sqrt(true_trials) << ":" << var2 / sqrt(true_trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}


void WriteoutDiffResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, std::vector<double> percentages, std::vector<std::vector<std::vector<double> > > iteration1, std::vector<std::vector<std::vector<double> > > iteration2)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < percentages.size(); s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << percentages[s];
		file_stderr << percentages[s];
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean1, var1;
		mean1 = var1 = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean1 = var1 = 0;
			int true_trials = trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					true_trials--;
					continue;
				}
				mean1 += fabs(iteration1[m][t][s] - iteration2[m][t][s]);
			}
			mean1 /= true_trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					continue;
				}
				double v = fabs(iteration1[m][t][s] - iteration2[m][t][s]);
				var1 += (v - mean1)*(v - mean1);
			}

			if (true_trials <= 1) {
				var1 = 0;
			}
			else {
				var1 /= (true_trials - 1);
				var1 = sqrt(var1);
			}

			file_mean << "\t" << mean1;
			file_stderr << "\t" << var1 / sqrt(true_trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}

void WriteoutMaxResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, std::vector<double> percentages, std::vector<std::vector<std::vector<double> > > iteration1, std::vector<std::vector<std::vector<double> > > iteration2)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < percentages.size(); s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << percentages[s];
		file_stderr << percentages[s];
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean1, var1;
		mean1 = var1 = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean1 = var1 = 0;
			int true_trials = trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					true_trials--;
					continue;
				}
				mean1 += std::max(iteration1[m][t][s], iteration2[m][t][s]);
			}
			mean1 /= true_trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					continue;
				}
				double v = std::max(iteration1[m][t][s], iteration2[m][t][s]);
				var1 += (v - mean1)*(v - mean1);
			}

			if (true_trials <= 1) {
				var1 = 0;
			}
			else {
				var1 /= (true_trials - 1);
				var1 = sqrt(var1);
			}

			file_mean << "\t" << mean1;
			file_stderr << "\t" << var1 / sqrt(true_trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}



void WriteoutMinResults(std::string filename_mean, std::string filename_stderr, std::vector<std::string> methods, int trials, std::vector<double> percentages, std::vector<std::vector<std::vector<double> > > iteration1, std::vector<std::vector<std::vector<double> > > iteration2)
{
	std::ofstream file_mean;
	std::ofstream file_stderr;

	file_mean.open(filename_mean.c_str());
	file_stderr.open(filename_stderr.c_str());

	file_mean << "Trials(" << trials << ")";
	file_stderr << "Trials(" << trials << ")";

	for (int m = 0; m < methods.size(); m++) {
		file_mean << "\t" << methods[m];
		file_stderr << "\t" << methods[m];
	}

	file_mean << std::endl;
	file_stderr << std::endl;

	for(int s = 0; s < percentages.size(); s++)
	{
		file_mean.precision(4);
		file_stderr.precision(4);
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean << percentages[s];
		file_stderr << percentages[s];
		file_mean << std::fixed;
		file_stderr << std::fixed;
		file_mean.precision(5);
		file_stderr.precision(5);

		double mean1, var1;
		mean1 = var1 = 0;

		for (int m = 0; m < methods.size(); m++) {
			mean1 = var1 = 0;
			int true_trials = trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					true_trials--;
					continue;
				}
				mean1 += std::min(iteration1[m][t][s], iteration2[m][t][s]);
			}
			mean1 /= true_trials;
			for (int t = 0; t < trials; t++) {
				if (isnan(iteration1[m][t][s]) or isnan(iteration2[m][t][s])) {
					continue;
				}
				double v = std::min(iteration1[m][t][s], iteration2[m][t][s]);
				var1 += (v - mean1)*(v - mean1);
			}

			if (true_trials <= 1) {
				var1 = 0;
			}
			else {
				var1 /= (true_trials - 1);
				var1 = sqrt(var1);
			}

			file_mean << "\t" << mean1;
			file_stderr << "\t" << var1 / sqrt(true_trials);
		}

		file_mean << std::endl;
		file_stderr << std::endl;
	}


	file_mean.close();
	file_stderr.close();
}

}

#endif /* LR_HPP_ */
