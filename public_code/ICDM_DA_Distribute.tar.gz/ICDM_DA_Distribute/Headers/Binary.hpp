
#ifndef BINARY_HPP_
#define BINARY_HPP_

#include <iomanip>

class Binary {
	double x[2][2];
	double x_normalized[2][2];
public:
	Binary() {
		x[0][0] = 0;
		x[0][1] = 0;
		x[1][0] = 0;
		x[1][1] = 0;
		x_normalized[0][0] = 0;
		x_normalized[0][1] = 0;
		x_normalized[1][0] = 0;
		x_normalized[1][1] = 0;
	}
	void setBoth(bool ylabel, double x0=.5, double x1=.5)
	{
		x[ylabel][0] = x0;
		x[ylabel][1] = x1;
	}
	void setAll(double xval=.5)
	{
		x[0][0] = x[0][1] = x[1][0] = x[1][1] = xval;
	}
	void setOne(bool ylabel, bool xlabel, double xval)
	{
		x[ylabel][xlabel] = xval;
	}
	void AddBinary(Binary b)
	{
		x[0][0] += b.get(0,0);
		x[0][1] += b.get(0,1);
		x[1][0] += b.get(1,0);
		x[1][1] += b.get(1,1);
	}
	void AddBinaryNormalized(Binary b)
	{
		x[0][0] += b.getNormalized(0,0);
		x[0][1] += b.getNormalized(0,1);
		x[1][0] += b.getNormalized(1,0);
		x[1][1] += b.getNormalized(1,1);
	}
	void setBinary(Binary b)
	{
		x[0][0] = b.get(0,0);
		x[0][1] = b.get(0,1);
		x[1][0] = b.get(1,0);
		x[1][1] = b.get(1,1);
	}
	void increment(bool ylabel, bool xlabel, double xval=1.0)
	{
		x[ylabel][xlabel] += xval;
	}
	std::pair<double, double> get(bool ylabel)
			{
		std::pair<double, double> vals;
		vals.first = x[ylabel][0];
		vals.second = x[ylabel][1];
		return vals;
			}
	double get(bool ylabel, bool xlabel) {
		return x[ylabel][xlabel];
	}
	double getNormalized(bool ylabel, bool xlabel) {
		return x_normalized[ylabel][xlabel];
	}
	void normalize()
	{
		double s = x[0][0] + x[0][1];
		x_normalized[0][0] = x[0][0] / s;
		x_normalized[0][1] = x[0][1] / s;
		s = x[1][0] + x[1][1];
		x_normalized[1][0] = x[1][0] / s;
		x_normalized[1][1] = x[1][1] / s;
	}
	void Print()
	{
		std::cout << "----------------------" << std::endl;
		std::cout << "\tX0:\tX1:" << std::endl;
		std::cout << std::fixed << std::setprecision(3) << "Y0:\t" << x[0][0] << "\t" << x[0][1] <<std::endl;
		std::cout << "Y1:\t" << x[1][0] << "\t" << x[1][1] <<std::endl;
		std::cout << "----------------------" << std::endl;
	}
	void PrintNormalized(std::ostream& fout = std::cout)
	{
		fout << "----------------------" << std::endl;
		fout << "\tX0:\tX1:" << std::endl;
		fout << std::fixed << std::setprecision(3) << "Y0:\t" << x_normalized[0][0] << "\t" << x_normalized[0][1] <<std::endl;
		fout << "Y1:\t" << x_normalized[1][0] << "\t" << x_normalized[1][1] <<std::endl;
		fout << "----------------------" << std::endl;
	}

};

#endif /* BINARY_HPP_ */
