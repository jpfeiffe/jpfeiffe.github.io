/*
 * Graph.hpp
 *
 *  Created on: Oct 10, 2012
 */





#if defined __FAST_MATH__
#   undef isnan
#endif
#if !defined isnan
#   define isnan isnan
#   include <stdint.h>
static inline int isnan(float f)
{
    union { float f; uint32_t x; } u = { f };
    return (u.x << 1) > 0xff000000u;
}
#endif





#ifndef UGRAPH_HPP_
#define UGRAPH_HPP_

#include "../ExternalCode/eigen3/Eigen/Sparse"
#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <istream>
#include <ostream>
#include <fstream>
#include <regex>

typedef Eigen::SparseMatrix<double, Eigen::RowMajor> eigen_matrix;
typedef Eigen::SparseMatrix<double> eigen_col_matrix;
typedef Eigen::VectorXd eigen_vector;

std::vector<std::string> split(const std::string &s, char delim)
{
    std::vector<std::string> elems;
    std::string item;

    // use stdlib to tokenize the string
    std::stringstream ss(s);
    while (std::getline(ss, item, delim))
        if(!item.empty())
            elems.push_back(item);

    return elems;
}



class UGraph{
protected:
	std::string _method_name;
	eigen_matrix graph;
	std::map<std::string, int> node_id_map;

public:
	UGraph(eigen_matrix g_in = eigen_matrix());
	virtual ~UGraph();

	// Import the file
	void ReadFile(std::string filename);

	// Get the neighbors
	std::vector<int> neighbors(int vert);

	// Degrees
	int degree(int vert);

	// General Statistics
	int num_edges();
	int num_vertices();

	// Copy off the graph
	eigen_matrix getGraph(){return graph;}

	// Naming stuff
	void setMethodName(std::string newname){_method_name = newname;}
	std::string getMethodName(){return _method_name;}
};


UGraph::UGraph(eigen_matrix g_in)
{
	graph = g_in;
	return;
}

UGraph::~UGraph() {

	return;
}


void UGraph::ReadFile(std::string filename) {
	std::ifstream f_in;
	std::string line;
	std::vector <std::string> fields;
	std::map <std::string, int> nodes;

	// Read in the edge file to get the node names
	f_in.open(filename.c_str());
	std::getline(f_in, line);
	while(f_in.good()){
		fields = split(line, ':');

		nodes[fields[0]] = 1;
		nodes[fields[1]] = 1;
		std::getline(f_in, line);
	}
	f_in.close();

	// Pair the nodes with corresponding ids
	int count = 0;
	for (std::pair <std::string, int> it : nodes) {
		node_id_map[it.first] = count;
		count++;
	}

	graph = eigen_matrix(count, count);
	typedef Eigen::Triplet<double> T;
	std::vector<T > tripletList;


	// Get the edges
	f_in.open(filename.c_str());
	std::getline(f_in, line);
	while(f_in.good()){
		fields = split(line, ':');
		int ind0 = node_id_map[fields[0].c_str()];
		int ind1 = node_id_map[fields[1].c_str()];
		tripletList.push_back(T(ind0, ind1, 1));
		tripletList.push_back(T(ind1, ind0, 1));
		std::getline(f_in, line);
	}
	f_in.close();

	graph.setFromTriplets(tripletList.begin(), tripletList.end());

	return;
}


std::vector<int> UGraph::neighbors(int vert) {
	std::vector<int> neigh;

	  for (eigen_matrix::InnerIterator it(graph,vert); it; ++it)
	  {
	    it.value();
	    it.row();   // row index
	    it.col();   // col index (here it is equal to k)
	    it.index(); // inner index, here it is equal to it.row()
	    neigh.push_back(it.col());
	  }

	return neigh;
}


int UGraph::degree(int vert) {
	return (int)neighbors(vert).size();
}


int UGraph::num_vertices() {
	return graph.rows();
}

int UGraph::num_edges() {
	return graph.nonZeros();
}

#endif /* GRAPH_HPP_ */
