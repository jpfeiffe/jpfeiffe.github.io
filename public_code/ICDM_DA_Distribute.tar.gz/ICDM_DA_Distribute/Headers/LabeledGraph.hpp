/*
 * LabeledGraph.hpp
 */



#ifndef LabeledGraph_HPP_
#define LabeledGraph_HPP_

#include "UGraph.hpp"
#include <bitset>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <unordered_map>
#include "Helpers.hpp"

typedef std::vector<int> X;
typedef int Y;

typedef std::unordered_map<int, X> XS;
typedef std::unordered_map<int, Y> YS;


class LabeledGraph : public UGraph{
protected:
	int _num_attr;
	XS xs;
	YS ys;

public:
	LabeledGraph(eigen_matrix new_graph = eigen_matrix(), int num_attr=2)
{
		_method_name = "LabeledGraph";
		_num_attr = num_attr; graph = new_graph;
}
	~LabeledGraph() {  }


	XS getXS() {return XS(xs);}
	YS getYS() {return YS(ys.begin(), ys.end());}
	YS getYS(std::vector<int> ids)
	{
		YS vals;
		for (int i = 0; i < ids.size(); i++) vals[ids[i]] = ys[ids[i]];
		return vals;
	}
	Y getY(int v) {return ys[v];}
	X getX(int v) {return xs[v];}
	std::vector<X> getXS(std::vector<int> vs)
			{
		std::vector<X> vals = std::vector<X>();
		for (int i = 0; i < vs.size(); i++) vals.push_back(X(xs[vs[i]]));
		return vals;
			}



	void setXS(std::vector<int> vs, std::vector<X> xvals)
	{
		for (int i = 0; i < vs.size(); i++) xs[vs[i]] = X(xvals[i].begin(), xvals[i].end());
	}
	void setXS(XS newxs) {xs = XS(newxs);}
	void setYS(YS newys) {ys = YS(newys);}

	virtual void setY(int v, int label) {ys[v]=label;}
	virtual void setX(int v, X features) {xs[v]=features;}

	int TotalLabels(int labels);

	int getNumberAttr(){return _num_attr;}

	virtual void SetupTester(XS);
	virtual void SetupEmptyTester(int count, int num_features);

	void ReadFile(std::string filename);

	double ComputeLabelCorrelation();
	std::map<int, int> retrieveLabelings(std::vector<int> vertices);

	std::vector<int> lab_neighbors(int v);
};


void LabeledGraph::SetupTester(XS new_xs) {
	xs.clear(); ys.clear();
	xs = XS(new_xs);
	XS::iterator x, x_end;
	x = new_xs.begin();
	x_end = new_xs.end();

	for(; x != x_end; x++) {
		ys[x->first] = -1;
	}

	graph = eigen_matrix(ys.size(), ys.size());

	return;
}




void LabeledGraph::SetupEmptyTester(int count, int num_features) {
	xs.clear(); ys.clear();

	for(int i = 0; i < count; i++) {
		ys[i] = -1;
		xs[i] = X();
		for (int j = 0; j < num_features; j++)
			xs[i].push_back(-1);
	}

	graph = eigen_matrix(ys.size(), ys.size());

	return;
}

std::map<int, int> LabeledGraph::retrieveLabelings(std::vector<int> vertices)
{
	std::vector<int>::iterator vi;
	std::map<int, int> labelings;

	for(vi = vertices.begin(); vi != vertices.end(); vi++) {
		labelings[*vi] = ys[*vi];
	}

	return labelings;
}



void LabeledGraph::ReadFile(std::string filename) {
	std::string label_in = filename + ".lab";
	std::string attr_in = filename + ".attr";
	std::string edges_in = filename + ".edges";

	std::ifstream f_in;
	std::string line;
	std::vector <std::string> fields;
	std::map <std::string, int> nodes;
	std::pair <std::string, int> it;

	UGraph::ReadFile(edges_in);

	f_in.open(label_in.c_str());
	while(std::getline(f_in, line)) {
		fields = split(line, ':');
		if (node_id_map.find(fields[0]) != node_id_map.end()) {
			int id = node_id_map[fields[0]];
			int val = stoi(fields[1]);
			ys[id] = val;
		}
	}

	f_in.close();
	f_in.open(attr_in.c_str());
	while(std::getline(f_in, line)) {
		fields = split(line, ':');

		if (node_id_map.find(fields[0]) != node_id_map.end()) {

			int id = node_id_map[fields[0]];

			xs[id] = std::vector<int>();
			for(int i=1; i < fields.size(); i++)
			{
				// This is only needed in case there are no attributes
				if(fields[i].length() > 0) {
					int attr = stoi(fields[i]);
					xs[id].push_back(attr);
				}
				_num_attr = xs[id].size();
			}
		}
	}
	f_in.close();
}


double LabeledGraph::ComputeLabelCorrelation()
{
	std::vector<double> sources, targets;

	for (int k=0; k<graph.outerSize(); ++k)
		for (eigen_matrix::InnerIterator it(graph,k); it; ++it)
		{
			it.value();
			it.row();   // row index
			it.col();   // col index (here it is equal to k)

			int x1val = ys[it.row()];
			int x2val = ys[it.col()];
			if (x1val >= 0 and x2val >= 0) {
				sources.push_back((double)x1val);
				targets.push_back((double)x2val);
				targets.push_back((double)x1val);
				sources.push_back((double)x2val);
			}
		}

	return Helpers::PearsonCorrelation(sources, targets);
}

#endif /* LabeledGraph_HPP_ */
