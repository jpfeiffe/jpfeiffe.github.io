/*
 * AS_LR.hpp
 */

#ifndef RLR_EM_HPP_
#define RLR_EM_HPP_


#include "RLR.hpp"
#include "liblinear/linear.h"





class RLR_EM : public RLR {
public:
public:
	enum REPRESENTATION {R_EM, R_SEM, R_SEM_VMF, R_DA};
	enum LEARNING_UPDATE {MF_APPROX, GIBBS};

protected:
	std::map<int, double > last_conditionals;
	std::unordered_map<int, std::vector<int>> last_samples;
	std::vector<double> expected_values;
	std::vector<int> gibbs_samples;
	int _em_iterate, _bp_iterate, _sem_final;
	LEARNING_UPDATE _learning_update;
	REPRESENTATION _representation;

	feature_node* featurize(int v, bool use_rel=true);

	double avg_expected_value;
	bool _last_init;
public:
	RLR_EM(eigen_matrix ugraph = eigen_matrix(), int num_attr=2, int num_em_iterations=5, int num_bp_iterations=3, REPRESENTATION rep=R_EM, LEARNING_UPDATE lupdate = MF_APPROX, NORMALIZATION norm = NONE)
: RLR(ugraph, num_attr, norm)
{
		_method_name = "EM";
		_em_iterate = num_em_iterations;
		_bp_iterate = num_bp_iterations;
		_sem_final = 100;
		_representation = rep;
		_learning_update = lupdate;

		// L2R_LR
		param.solver_type = 0;
		param.C = 1;
		param.eps = 0.01; // see setting below
		param.p = 0.1;
		param.nr_weight = 0;
		param.weight_label = NULL;
		param.weight = NULL;

		avg_expected_value = 0;
		_last_init = false;
}

	~RLR_EM()
	{
		if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}
		if (_means != NULL) {delete _means; _means = NULL;}
		if (_stds != NULL) {delete _stds; _stds = NULL;}
	}

	void setLastInit(bool v) {_last_init = v;}

	virtual RLR_EM* Clone();

	void EStep(int em_iteration, int bp_iterations,
			std::vector<double>& border_feature_pos, std::vector<double>& border_feature_neg,
			std::vector<double>& bp_iteration_expectation_summation, std::vector<double>& bp_iteration_gibbs_summation, std::vector<double>& all_em_iteration_expectation_summation, std::vector<double>& all_em_iteration_gibbs_summation);

	void MStep(std::unordered_set<int> positives, std::unordered_set<int> negatives);

	virtual void learnModel();
	void setEMIterations(int num_iter) {_em_iterate = num_iter;}
	void setBPIterations(int num_iter) {_bp_iterate = num_iter;}
	void setSEMFinal(int num_iter) {_sem_final = num_iter;}
	void computeConditionals();
	//	double computeVariationalJacobianMaxEigenvalue(){return _max_jacobian;}
};


RLR_EM* RLR_EM::Clone()
{
	RLR_EM *newrlr = new RLR_EM(graph, _num_attr,  _em_iterate, _bp_iterate, _representation, _learning_update);
	return newrlr;
}


feature_node* RLR_EM::featurize(int v, bool use_uncertain)
{
	feature_node* feat_array = new feature_node[_num_attr+3];
	for(int i = 0; i < xs[v].size(); i++)
	{
		feat_array[i].index = i+1;
		feat_array[i].value = xs[v][i];
	}

	feat_array[_num_attr].index = _num_attr+1;
	feat_array[_num_attr].value = 0;
	feat_array[_num_attr+1].index = _num_attr+2;
	feat_array[_num_attr+1].value = 0;

	// Regular RLR
	if (!use_uncertain) {
		for (const int& neigh : lab_neighbors(v)) {
			feat_array[_num_attr + ys[neigh]].value++;
		}
	}

	// Labeled/Deterministic
	else if (_labeled_vertices.find(v) != _labeled_vertices.end() or _learning_update == MF_APPROX) {
		for (const int& neigh : neighbors(v)) {
			if (_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
				feat_array[_num_attr + ys[neigh]].value++;
			}
			else {
				feat_array[_num_attr].value += (1-expected_values[neigh]);
				feat_array[_num_attr+1].value += (expected_values[neigh]);
			}
		}
	}

	// Gibbs version
	else if (_learning_update == GIBBS) {
		for (const int& neigh : neighbors(v)) {
			if (_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
				feat_array[_num_attr + ys[neigh]].value++;
			}
			else {
				feat_array[_num_attr].value += (1-gibbs_samples[neigh]);
				feat_array[_num_attr+1].value += (gibbs_samples[neigh]);
			}
		}
	}


	feat_array[_num_attr+2].index = -1;
	return feat_array;
}



void RLR_EM::learnModel()
{
	double p_old(0), p_new(0);
	double n_old(0), n_new(0);

	// For SEM
	double *w_agg = new double[_num_attr+2];
	for (int i = 0; i < _num_attr+2; i++) w_agg[i] = 0;

	// For recording results
	_w00.clear(); _w01.clear(); _w10.clear(); _w11.clear();

	// With RNB no reason to continually recompute the features
	std::vector<double> border_feature_pos; border_feature_pos.resize(num_vertices(), 0);
	std::vector<double> border_feature_neg; border_feature_neg.resize(num_vertices(), 0);

	// Used for EM or Gibbs Sampling
	expected_values.assign((int)num_vertices(), 0.0);
	gibbs_samples.assign((int)num_vertices(), 0.0);

	// Some summations we will keep track of
	std::vector<double> bp_iteration_expectation_summation; bp_iteration_expectation_summation.resize(num_vertices(), 0);
	std::vector<double> bp_iteration_gibbs_summation; bp_iteration_gibbs_summation.resize(num_vertices(), 0);
	std::vector<double> all_em_iteration_expectation_summation; all_em_iteration_expectation_summation.resize(num_vertices(), 0);
	std::vector<double> all_em_iteration_gibbs_summation; all_em_iteration_gibbs_summation.resize(num_vertices(), 0);

	last_samples.clear();

	// Get some initial expectations
	RLR::learnModel();

	// Actually do our own work now -- have to give them in order is all here
	std::unordered_set<int> positives;
	std::unordered_set<int> negatives;
	// Need to assign the Random Walk weightings between every pair of edges
	for (const int& v : _labeled_vertices) {
		if (ys[v] == 1) positives.insert(v);
		else negatives.insert(v);
	}

	_within_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.clear();
	_converged_values.clear();

	double j;
	bool true_last_init = _last_init;
	if (_representation == R_SEM or _representation == R_SEM_VMF or _representation == R_DA) {
		_last_init = true;
	}
	for (int em_iteration = 0; em_iteration < _em_iterate; em_iteration++) {
		EStep(em_iteration, _bp_iterate, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);

		// How are we going to represent the update?
		switch (_representation) {
		case R_EM:
			// If we're using R-EM & Gibbs need to compute the E-step
			if (_learning_update == GIBBS) {
				for (const int& v : _unlabeled_vertices) {
					expected_values[v] = bp_iteration_gibbs_summation[v] / _bp_iterate;
				}
			}
			break;
		case R_SEM and R_SEM_VMF:
		// Intentional Fallthrough
		case R_DA:
			for (const int& v : _unlabeled_vertices)
				expected_values[v] = gibbs_samples[v];
			break;
		}

		if (_representation == R_EM and em_iteration >= _em_iterate-2) {
			SetJacobianConditionals(expected_values);
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_within_iteration_eigenvalues.push_back(j);
		}
		if (_representation == R_EM and _em_iterate==1) {
			SetJacobianConditionals(expected_values);
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_within_iteration_eigenvalues.push_back(j);
		}


		MStep(positives, negatives);


		if (em_iteration == _em_iterate-2) {
			n_old = lr_model->w[lr_model->nr_feature - 2];
			p_old = lr_model->w[lr_model->nr_feature - 1];
		}
		else if (em_iteration == _em_iterate-1) {
			n_new = lr_model->w[lr_model->nr_feature - 2];
			p_new = lr_model->w[lr_model->nr_feature - 1];
		}

		if (_representation == R_EM and em_iteration >= _em_iterate-2) {
			SetJacobianConditionals(expected_values);
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_cross_iteration_eigenvalues.push_back(j);
			SetJacobianConditionals(GetTrueConditionals());
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_perfect_iteration_eigenvalues.push_back(j);
			_converged_values.push_back(avg_expected_value);
		}
		if (_representation == R_EM and _em_iterate==1) {
			SetJacobianConditionals(expected_values);
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_cross_iteration_eigenvalues.push_back(j);
			SetJacobianConditionals(GetTrueConditionals());
			j = RLR::computeVariationalJacobianMaxEigenvalue();
			_perfect_iteration_eigenvalues.push_back(j);
			_converged_values.push_back(avg_expected_value);
		}



		_w00.push_back(lr_model->w[_num_attr]);
		_w01.push_back(-1);
		_w10.push_back(lr_model->w[_num_attr+1]);
		_w11.push_back(-1);

		for (int agg = 0; agg < _num_attr+2; agg++)
			w_agg[agg] += lr_model->w[agg];
	}

	// Normalize the aggregate
	for (int agg = 0; agg < _num_attr+2; agg++) {
		lr_model->w[agg] = w_agg[agg] / _em_iterate;
	}

	_last_init = true_last_init;

	// How are we going to represent the finalized version?
	switch (_representation) {
	// No additional E-Step
	case R_DA:
		for (const int& v : _unlabeled_vertices) {
			expected_values[v] = all_em_iteration_gibbs_summation[v] / (_bp_iterate * (_em_iterate));
			avg_expected_value += expected_values[v];
		}
		avg_expected_value /= _unlabeled_vertices.size();
		break;

		// Gibbs E-Step
	case R_SEM:
		EStep(_em_iterate+1, _sem_final, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);
		avg_expected_value = 0;
		for (const int& v : _unlabeled_vertices) {
			expected_values[v] = bp_iteration_gibbs_summation[v] / _sem_final;
			avg_expected_value += expected_values[v];
		}
		avg_expected_value /= _unlabeled_vertices.size();
		break;

		// VMF E-Step
	case R_SEM_VMF:
		_learning_update = MF_APPROX;
		EStep(_em_iterate+1, _sem_final, border_feature_pos, border_feature_neg,
				bp_iteration_expectation_summation, bp_iteration_gibbs_summation, all_em_iteration_expectation_summation, all_em_iteration_gibbs_summation);
		_learning_update = GIBBS;
		break;
	}

	// Store their representative values
	if (_representation == R_SEM or _representation == R_SEM_VMF or _representation == R_DA)
	{
		_converged_values.push_back(avg_expected_value);
		_converged_values.push_back(avg_expected_value);
		SetJacobianConditionals(expected_values);
		j = RLR::computeVariationalJacobianMaxEigenvalue();
		_within_iteration_eigenvalues.push_back(j);
		_within_iteration_eigenvalues.push_back(j);
		SetJacobianConditionals(GetTrueConditionals());
		j = RLR::computeVariationalJacobianMaxEigenvalue();
		_perfect_iteration_eigenvalues.push_back(j);
		MStep(positives, negatives);
		SetJacobianConditionals(expected_values);
		j = RLR::computeVariationalJacobianMaxEigenvalue();
		_cross_iteration_eigenvalues.push_back(j);
		_cross_iteration_eigenvalues.push_back(j);
		SetJacobianConditionals(GetTrueConditionals());
		j = RLR::computeVariationalJacobianMaxEigenvalue();
		_perfect_iteration_eigenvalues.push_back(j);
	}



	last_conditionals.clear();
	for (const int& v : _unlabeled_vertices)	{
		last_conditionals[v] = expected_values[v];
	}


	_param_variance = (p_old - p_new)*(p_old - p_new);
	_param_variance += (n_old - n_new)*(n_old - n_new);

	delete w_agg;
}



void RLR_EM::MStep(std::unordered_set<int> positives, std::unordered_set<int> negatives)
{
	if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}


	problem prob;
	prob.l = _labeled_vertices.size();
	prob.n = this->_num_attr + 2;
	prob.bias = -1;
	prob.y = new double[prob.l];
	prob.x = new feature_node*[prob.l];

	int ind=0;

	for (const int& v : negatives) {
		prob.y[ind] = ys[v];
		prob.x[ind++] = featurize(v, true);
	}

	for (const int& v : positives) {
		prob.y[ind] = ys[v];
		prob.x[ind++] = featurize(v, true);
	}

	normalize(prob.x, prob.l);

	lr_model = train(&prob, &param);

	for (int i = 0; i < prob.l; i++) {
		delete prob.x[i];
	}

	delete prob.x;
	delete prob.y;
}




void RLR_EM::EStep(int em_iteration, int bp_iterations,
		std::vector<double>& border_feature_pos, std::vector<double>& border_feature_neg,
		std::vector<double>& bp_iteration_expectation_summation, std::vector<double>& bp_iteration_gibbs_summation, std::vector<double>& all_em_iteration_expectation_summation, std::vector<double>& all_em_iteration_gibbs_summation)
{
	double prob_estimates[2];

	_total_positives.clear();
	_total_negatives.clear();
	std::vector<int> estimating_vertices(_unlabeled_vertices.begin(), _unlabeled_vertices.end());
	// Loop over all the iterations
	for (int bp_iteration = 0; bp_iteration < bp_iterations; bp_iteration++) {
		avg_expected_value = 0;
		double count = 0;
		double num_positives = 0;
		std::random_shuffle(estimating_vertices.begin(), estimating_vertices.end());
		for (const int& v : estimating_vertices) {
			count++;
			// Update the expectations and draw a gibbs sample
			double old_e = expected_values[v];

			feature_node* feat_array = featurize(v, (bp_iteration > 0 or (em_iteration > 0 and _last_init)));
			normalize(feat_array);
			predict_probability(lr_model, feat_array, prob_estimates);

			delete(feat_array);
			double prob = prob_estimates[1];

			expected_values[v] = prob;
			gibbs_samples[v] = ((double)rand())/RAND_MAX < expected_values[v];
			last_samples[v].push_back(gibbs_samples[v]);
			avg_expected_value += gibbs_samples[v];
			if (gibbs_samples[v] == 1)
				num_positives++;

			// Reset the various iterations if necessary
			if (bp_iteration == 0) {
				bp_iteration_expectation_summation[v] = 0;
				bp_iteration_gibbs_summation[v] = 0;
				if (em_iteration == 0) {
					all_em_iteration_expectation_summation[v] = 0;
					all_em_iteration_gibbs_summation[v] = 0;
				}
			}
			// Update the sums
			bp_iteration_expectation_summation[v] += expected_values[v];
			all_em_iteration_expectation_summation[v] += expected_values[v];
			bp_iteration_gibbs_summation[v] += gibbs_samples[v];
			all_em_iteration_gibbs_summation[v] += gibbs_samples[v];
		}

		avg_expected_value /= estimating_vertices.size();
		_total_positives.push_back(num_positives);
		_total_negatives.push_back(estimating_vertices.size() - num_positives);
	}

}


void RLR_EM::computeConditionals()
{
	for (std::pair<int,double> v : last_conditionals) {
		conditionals[v.first] = v.second;
	}
}


#endif /* AS_LR_HPP_ */
