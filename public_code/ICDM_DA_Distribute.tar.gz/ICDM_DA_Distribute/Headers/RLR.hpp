/*
 * AS_LR.hpp
 */

#ifndef RLR_HPP_
#define RLR_HPP_

#include "LR.hpp"
#include "liblinear/linear.h"

class RLR : public LR {
protected:

	virtual void normalize(feature_node** data, int num_instances);
	virtual void normalize(feature_node*data);

	virtual void normalize01(feature_node** data, int num_instances);
	virtual void normalize01(feature_node* data);

	virtual feature_node* featurize(int v, bool use_rel=true);

public:
	RLR(eigen_matrix new_graph=eigen_matrix(), int num_attr=2, NORMALIZATION norm = NONE)
: LR(new_graph, num_attr, norm)
{
		_method_name = "RLR";

		// L2R_LR
		param.solver_type = 0;
		param.C = 1;
		param.eps = 0.01; // see setting below
		param.p = 0.1;
		param.nr_weight = 0;
		param.weight_label = NULL;
		param.weight = NULL;

		lr_model = NULL;
		_means = NULL;
		_stds = NULL;
}

	~RLR()
	{
		if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}
		if (_means != NULL) {delete _means; _means = NULL;}
		if (_stds != NULL) {delete _stds; _stds = NULL;}
	}

	virtual RLR* Clone();

	virtual void learnModel();

	double computeConditional(int v, bool use_rel);

	double computeVariationalJacobianMaxEigenvalue();

	void computeConditionals();
	void computeLabeledConditionals();
};


RLR* RLR::Clone()
{
	RLR* newrlr = new RLR(eigen_matrix(graph), _num_attr, _norm);
	return newrlr;
}





void RLR::normalize01(feature_node** data, int num_instances)
{
	if (_means == NULL) _means = new double[_num_attr+2];
	if (_stds == NULL) _stds = new double[_num_attr+2];

	for (int i = 0; i < _num_attr+2; i++)
	{
		double mean = 0;
		double std = 0;
		for (int j = 0; j < num_instances; j++)
		{
			mean += data[j][i].value;
		}

		// Don't bother if they're all 0s
		if (mean == 0) {_stds[i] = -1; continue;}

		mean /= num_instances;
		for (int j = 0; j < num_instances; j++)
		{
			std += (data[j][i].value - mean)*(data[j][i].value - mean);
		}

		// Don't bother if all the same value
		if (std == 0)  {_stds[i] = -1; continue;}

		std /= (num_instances - 1);
		std = sqrt(std);

		_means[i] = mean;
		_stds[i] = std;
	}

	for (int j = 0; j < num_instances; j++)
	{
		normalize01(data[j]);
	}
}


void RLR::normalize01(feature_node* data)
{
	for (int i = 0; i < _num_attr+2; i++)
	{
		double mean = _means[i];
		double std = _stds[i];

		if (std < 0) {data[i].value = 0; continue;}

		data[i].value = (data[i].value - mean) / std;
	}
}






void RLR::normalize(feature_node** data, int num_instances)
{
	if (_norm == ZERO_ONE)
		normalize01(data, num_instances);
}


void RLR::normalize(feature_node* data)
{
	if (_norm == ZERO_ONE)
		normalize01(data);
}




feature_node* RLR::featurize(int v, bool use_rel)
{
	feature_node* feat_array = new feature_node[_num_attr+3];
	for(int i = 0; i < xs[v].size(); i++)
	{
		feat_array[i].index = i+1;
		feat_array[i].value = xs[v][i];
	}

	feat_array[_num_attr].index = _num_attr+1;
	feat_array[_num_attr].value = 0;
	feat_array[_num_attr+1].index = _num_attr+2;
	feat_array[_num_attr+1].value = 0;

	if (use_rel) {
		for (const int& neigh : lab_neighbors(v)) {
			feat_array[_num_attr + ys[neigh]].value++;
		}
	}
	feat_array[_num_attr+2].index = -1;
	return feat_array;
}



void RLR::learnModel()
{
	std::unordered_set<int> positives;
	std::unordered_set<int> negatives;

	if (lr_model != NULL) {free_and_destroy_model(&lr_model); lr_model = NULL;}
	int samples = 0;

	problem prob;
	prob.l = _labeled_vertices.size();
	prob.n = this->_num_attr + 2;
	prob.bias = -1;
	prob.y = new double[prob.l];
	prob.x = new feature_node*[prob.l];

	int ind=0;
	for (int v : _labeled_vertices) {
		if (ys[v] == 1) positives.insert(v);
		else negatives.insert(v);
	}

	for (int v : negatives) {
		prob.y[ind] = ys[v];
		prob.x[ind++] = featurize(v);
	}


	for (int v : positives) {
		prob.y[ind] = ys[v];
		prob.x[ind++] = featurize(v);
	}


	normalize(prob.x, prob.l);
	lr_model = train(&prob, &param);

	for (int i = 0; i < prob.l; i++) {
		delete prob.x[i];
	}

	delete prob.x;
	delete prob.y;
}



double RLR::computeConditional(int v, bool use_rel=true)
{
	double prob_estimates[2];
	feature_node* feat_array= featurize(v, use_rel);
	normalize(feat_array);
	predict_probability(lr_model, feat_array, prob_estimates);
	delete feat_array;
	double prob = prob_estimates[1];

	return prob;
}


void RLR::computeConditionals()
{
	conditionals.clear();

	feature_node* feat_array;
	double prob_estimates[2];

	double average = 0;
	for(int v : _unlabeled_vertices)
	{
		feat_array = featurize(v);
		normalize(feat_array);
		predict_probability(lr_model, feat_array, prob_estimates);

		double prob = prob_estimates[1];
		conditionals[v] = prob;
		delete feat_array;
		average += prob;
	}

	average /= _unlabeled_vertices.size();

	_within_iteration_eigenvalues.clear();
	this->SetJacobianConditionals(conditionals);
	double j = this->computeVariationalJacobianMaxEigenvalue();
	_within_iteration_eigenvalues.push_back(j);
	_within_iteration_eigenvalues.push_back(j);

	_cross_iteration_eigenvalues.clear();
	_cross_iteration_eigenvalues.push_back(j);
	_cross_iteration_eigenvalues.push_back(j);

	this->SetJacobianConditionals(true_conditionals);
	j = this->computeVariationalJacobianMaxEigenvalue();
	_perfect_iteration_eigenvalues.clear();
	_perfect_iteration_eigenvalues.push_back(j);
	_perfect_iteration_eigenvalues.push_back(j);
	_converged_values.clear();
	_converged_values.push_back(average);
	_converged_values.push_back(average);

}

void RLR::computeLabeledConditionals()
{
	conditionals.clear();

	feature_node* feat_array;
	double prob_estimates[2];

	for(int v : _labeled_vertices)
	{
		feat_array = featurize(v);
		normalize(feat_array);
		predict_probability(lr_model, feat_array, prob_estimates);

		double prob = prob_estimates[1];
		conditionals[v] = prob;
		delete feat_array;
	}
}




double RLR::computeVariationalJacobianMaxEigenvalue()
{
	std::unordered_set<int> into_jacobian;
	for(int v : _unlabeled_vertices) {
		// Include edges
		for (int neigh : unlab_neighbors(v)) {
			into_jacobian.insert(v);
			break;
		}
	}

	// Current setup is for the binary |U|x|U| matrix
	eigen_matrix jacobian(into_jacobian.size()*2, into_jacobian.size()*2);


	// Create a mapping from the unlabeled vertex ids to the jacobian we're using
	std::unordered_map<int, int> unlabeled_j_ids;
	int id = 0;
	for(int v : into_jacobian)
		unlabeled_j_ids[v] = id++;

	// Fill in the Jacobian
	double max_abs_deg, min_abs_deg, maxneigh;
	maxneigh = 0;
	min_abs_deg = 1000;
	max_abs_deg = -1;
	feature_node* feat_array = new feature_node[_num_attr+3];

	double exponents[2];

	double neg_weight = lr_model->w[_num_attr];
	double pos_weight = lr_model->w[_num_attr+1];

	double total_abs_sum = 0;

	typedef Eigen::Triplet<double> T;
	std::vector<T > tripletList;

	for(int v : into_jacobian) {
		// Begin by computing the 'g' function (expectation of the log unnormalized energy)
		// Initial probs

		for(int i = 0; i < xs[v].size(); i++)
		{
			feat_array[i].index = i+1;
			feat_array[i].value = xs[v][i];
		}

		feat_array[_num_attr].index = _num_attr+1;
		feat_array[_num_attr].value = 0;
		feat_array[_num_attr+1].index = _num_attr+2;
		feat_array[_num_attr+1].value = 0;


		for (const int& neigh : neighbors(v)) {
			if (_labeled_vertices.find(neigh) != _labeled_vertices.end()) {
				feat_array[_num_attr + ys[neigh]].value++;
			}
			else {
				feat_array[_num_attr].value += (1-jacobian_conditionals[neigh]);
				feat_array[_num_attr+1].value += (jacobian_conditionals[neigh]);
			}
		}

		feat_array[_num_attr+2].index = -1;
		normalize(feat_array);
		predict_values(lr_model, feat_array, exponents);

		// These are our exponential components
		// It is in terms of exppos because that's what liblinear works with
		double exp_pos = exp(0);
		double exp_neg = exp(-1*exponents[0]);
		double partition = exp_pos + exp_neg;

		// These are the four possible partial derivatives for RNB.  They do not depend on the actual value of the unlabeled neighbor
		double pos_i_pos_j_partial = (pos_weight*exp_neg) / (partition * partition);
		double pos_i_neg_j_partial = (neg_weight*exp_neg) / (partition * partition);
		double neg_i_pos_j_partial = (-1*pos_weight*exp_neg) / (partition * partition);
		double neg_i_neg_j_partial = (-1*neg_weight*exp_neg) / (partition * partition);

		/*	Matrix structure
		 * 		v_j
		v_i		P-P | P-N
				N-P | N-N
		 */
		// Assign for each unlabeled neighbor
		int v_jacobian_id_pos = unlabeled_j_ids[v];
		int v_jacobian_id_neg = unlabeled_j_ids[v]+into_jacobian.size();
		for (int neigh : unlab_neighbors(v)) {
			// Only need the unlabeled neighbors
			int n_jacobian_id_pos = unlabeled_j_ids[neigh];
			int n_jacobian_id_neg = unlabeled_j_ids[neigh]+into_jacobian.size();
			tripletList.push_back(T(v_jacobian_id_pos, n_jacobian_id_pos, pos_i_pos_j_partial));
			tripletList.push_back(T(v_jacobian_id_pos, n_jacobian_id_neg, pos_i_neg_j_partial));
			tripletList.push_back(T(v_jacobian_id_neg, n_jacobian_id_pos, neg_i_pos_j_partial));
			tripletList.push_back(T(v_jacobian_id_neg, n_jacobian_id_neg, neg_i_neg_j_partial));

			total_abs_sum += (fabs(pos_i_pos_j_partial) + fabs(pos_i_neg_j_partial) + fabs(neg_i_pos_j_partial) + fabs(neg_i_neg_j_partial));
		}
	}


	delete feat_array;

	// Error case
	if (total_abs_sum == 0) return 0;

	jacobian.setFromTriplets(tripletList.begin(), tripletList.end());

	double maxval = Helpers::PowerMethod(jacobian);

	return maxval;
	//	return -1;
}


#endif /* AS_LR_HPP_ */
